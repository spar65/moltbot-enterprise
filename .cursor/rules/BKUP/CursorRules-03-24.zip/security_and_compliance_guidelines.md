# Cursor Security & Compliance Guidelines

These guidelines instruct Cursor on how to assist with security and compliance aspects of software development. They define how Cursor should analyze code for vulnerabilities, suggest security improvements, and help implement compliance requirements, ensuring recommendations are precise, actionable, and context-aware.

---

## Security Review Assistance

### Automated Security Analysis

**Code Analysis:**
- Proactively scan code for common security vulnerabilities (e.g., SQL injection, XSS).
- Identify OWASP Top 10 vulnerabilities in web applications.
- Flag insecure coding patterns (e.g., improper error handling) and suggest secure alternatives.
- Detect hardcoded credentials and sensitive information (e.g., API keys, passwords).
- **Recommended Tools**: Use static analysis tools like SonarQube or Semgrep for automated scanning.

**Security Documentation:**
- Generate security documentation templates (e.g., threat models, security checklists).
- Suggest documenting security features (e.g., authentication methods, encryption).
- Help create threat models for sensitive components.
- Provide checklists for manual security reviews.

**Review Prioritization:**
- Identify high-risk areas of code (e.g., authentication, payment processing) for deeper review.
- Suggest prioritizing security issues based on severity (e.g., Critical, High, Medium).
- Flag components handling sensitive data (e.g., PII, financial data).
- Recommend security testing focus areas (e.g., input validation, session management).

---

## Dependency Management

### Vulnerability Detection

**Dependency Analysis:**
- Identify outdated or vulnerable dependencies.
- Recognize dependency version conflicts.
- Flag dependencies with known security issues.
- Suggest secure alternatives for problematic libraries.

**Update Recommendations:**
- Recommend specific version updates to address vulnerabilities.
- Analyze potential breaking changes in dependency updates (e.g., review changelogs, run tests).
- Suggest incremental update paths for major version changes.
- Generate updated dependency configuration files (e.g., `package.json`, `requirements.txt`).

**Dependency Scanning Integration:**
- Suggest integrations with tools like Dependabot or Snyk for automated updates.
- Generate configuration for dependency scanning tools.
- Recommend CI/CD pipeline integration for dependency checks.
- Flag dependencies without vulnerability monitoring.
- **License Compliance**: Recommend checking license compatibility for dependencies.

---

## Vulnerability Remediation

### Secure Coding Suggestions

**Vulnerability Fixes:**
- Provide specific code suggestions to fix identified vulnerabilities (e.g., use parameterized queries for SQL injection).
- Recommend proper input validation techniques (e.g., allowlisting, sanitization).
- Suggest secure authentication and authorization patterns (e.g., OAuth, JWT).
- Generate secure configuration for common frameworks (e.g., Flask, Express).

**Security Pattern Implementation:**
- Recommend implementation of security headers (e.g., CSP, HSTS).
- Suggest secure password storage (e.g., bcrypt, Argon2) and validation methods.
- Provide patterns for secure API design (e.g., rate limiting, API key rotation).
- Generate code for implementing proper access controls (e.g., RBAC).

**Framework-Specific Security:**
- Suggest framework-specific security best practices (e.g., Flask’s `flask-talisman` for security headers).
- Identify security features available in used frameworks (e.g., Spring Security for Java).
- Recommend secure configuration options (e.g., enabling CSRF protection).
- Flag disabled or misconfigured security features.

---

## Compliance Support

### Regulatory Guidance

**Compliance Identification:**
- Identify potential regulatory requirements based on application type (e.g., GDPR for EU users, HIPAA for health data).
- Suggest compliance considerations for different data types (e.g., PII, financial data).
- Flag patterns that might violate common regulations (e.g., storing unencrypted PII).
- Recommend compliance documentation templates (e.g., data protection impact assessments).

**Privacy Implementation:**
- Suggest implementations for data privacy requirements (e.g., data minimization).
- Recommend patterns for user consent management (e.g., consent banners, logs).
- Generate code for data anonymization or pseudonymization.
- Identify personally identifiable information (PII) handling.

**Audit Trail Implementation:**
- Recommend audit logging for sensitive operations (e.g., user data access).
- Suggest non-repudiation mechanisms where required (e.g., digital signatures).
- Generate code for secure audit trail implementation.
- Flag insufficient logging of security-relevant events.

**Data Retention:**
- Recommend data retention policies (e.g., delete user data after account closure).
- Suggest automated data purging mechanisms.

---

## Authentication & Authorization

### Access Control Enhancement

**Authentication Security:**
- Identify weak authentication mechanisms (e.g., single-factor auth for sensitive systems).
- Suggest multi-factor authentication (MFA) implementation (e.g., TOTP, SMS).
- Recommend secure session management (e.g., short-lived tokens, HTTPS-only cookies).
- Generate code for implementing authentication security.

**Authorization Patterns:**
- Suggest proper authorization checks (e.g., before accessing resources).
- Identify missing permission validations.
- Recommend role-based access control (RBAC) implementations.
- Generate code for implementing authorization patterns.

**Credential Management:**
- Suggest secure credential storage (e.g., hashed passwords).
- Recommend secure password reset flows (e.g., token-based resets).
- Identify insecure credential handling (e.g., plaintext storage).
- Generate code for implementing credential validation.

---

## Data Protection

### Sensitive Data Handling

**Data Encryption:**
- Identify unencrypted sensitive data (e.g., credit card numbers).
- Suggest appropriate encryption methods (e.g., AES-256 for data at rest).
- Recommend key management practices (e.g., AWS KMS, HashiCorp Vault).
- Generate code for implementing encryption.

**Data Validation:**
- Suggest input validation for all user-supplied data.
- Recommend output encoding to prevent injection attacks (e.g., HTML entity encoding).
- Identify missing data sanitization.
- Generate code for implementing data validation (e.g., using OWASP ESAPI).

**Data Exposure Prevention:**
- Identify potential data leakage points (e.g., detailed error messages).
- Suggest proper error handling to prevent information disclosure (e.g., generic error messages).
- Recommend logging practices that protect sensitive data (e.g., masking PII).
- Flag overly verbose error messages or logs.

---

## Implementation Examples

### Example: SQL Injection Prevention (Python)

```python
# Vulnerable code
def get_user(username):
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return cursor.fetchone()

Cursor suggestion:
python

# Secure parameterized query
def get_user(username):
    """Retrieve user by username using parameterized query to prevent SQL injection."""
    query = "SELECT * FROM users WHERE username = %s"
    cursor.execute(query, (username,))
    return cursor.fetchone()

Example: Secure Password Storage (JavaScript)
javascript

// Insecure password storage
function createUser(username, password) {
  const user = {
    username: username,
    password: password  // Storing plaintext password
  };
  return db.users.insert(user);
}

Cursor suggestion:
javascript

// Secure password hashing
const bcrypt = require('bcrypt');

async function createUser(username, password) {
  const saltRounds = 12;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  const user = {
    username: username,
    password: hashedPassword
  };

  return db.users.insert(user);
}

Example: Security Headers Implementation (Express)
javascript

// Express app without security headers
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000);

Cursor suggestion:
javascript

// Express app with security headers
const express = require('express');
const helmet = require('helmet');

const app = express();

app.use(helmet());

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:"],
      },
    },
    referrerPolicy: { policy: "same-origin" },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true }
  })
);

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000);

Example: GDPR Data Subject Rights Implementation (Python)
python

# Controller handling user data without GDPR considerations
class UserController:
    def create_user(self, user_data):
        return db.users.insert(user_data)

    def get_user(self, user_id):
        return db.users.find_by_id(user_id)

Cursor suggestion:
python

# GDPR-compliant user controller
class UserController:
    def create_user(self, user_data, consent=None):
        if consent is None:
            consent = {}

        user_record = {
            **user_data,
            "consent": consent,
            "consent_timestamp": datetime.now().isoformat(),
            "data_collected_at": datetime.now().isoformat()
        }

        audit_logger.info("User consent recorded", extra={
            "user_id": user_record.get("id"), "consent": consent
        })

        return db.users.insert(user_record)

    def get_user(self, user_id):
        return db.users.find_by_id(user_id)

    def delete_user(self, user_id):
        user = db.users.find_by_id(user_id)
        if not user:
            return {"error": "User not found"}

        audit_logger.info("User data deleted per request", extra={"user_id": user_id})
        return db.users.delete(user_id)

    def export_user_data(self, user_id):
        user = db.users.find_by_id(user_id)
        if not user:
            return {"error": "User not found"}

        portable_data = {
            k: v for k, v in user.items() if k not in ["internal_id", "tracking_data"]
        }

        audit_logger.info("User data exported", extra={"user_id": user_id})
        return portable_data

Additional Example: CSRF Protection (Flask)
python

# Vulnerable Flask app without CSRF protection
from flask import Flask, request

app = Flask(__name__)

@app.route('/update', methods=['POST'])
def update():
    data = request.form['data']
    # Process data
    return "Updated"

Cursor suggestion:
python

# Flask app with CSRF protection
from flask import Flask, request
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'
csrf = CSRFProtect(app)

@app.route('/update', methods=['POST'])
@csrf.exempt  # Use selectively; ideally, include CSRF tokens in forms
def update():
    data = request.form['data']
    # Process data
    return "Updated"

Additional Example: Secure File Uploads (Node.js)
javascript

// Insecure file upload
app.post('/upload', (req, res) => {
  const file = req.files.file;
  file.mv('./uploads/' + file.name);
  res.send('File uploaded');
});

Cursor suggestion:
javascript

// Secure file upload with validation
const path = require('path');
const crypto = require('crypto');

app.post('/upload', (req, res) => {
  const file = req.files.file;
  const extension = path.extname(file.name);
  const allowedExtensions = ['.jpg', '.png', '.pdf'];
  
  if (!allowedExtensions.includes(extension)) {
    return res.status(400).send('Invalid file type');
  }
  
  const filename = crypto.randomBytes(16).toString('hex') + extension;
  file.mv('./uploads/' + filename);
  res.send('File uploaded securely');
});

Additional Example: HIPAA Compliance (Data Encryption)
python

# Storing patient data without encryption
def store_patient_data(patient_data):
    db.patients.insert(patient_data)

Cursor suggestion:
python

# Encrypting sensitive patient data for HIPAA compliance
from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher = Fernet(key)

def store_patient_data(patient_data):
    encrypted_data = {
        "name": cipher.encrypt(patient_data["name"].encode()).decode(),
        "dob": cipher.encrypt(patient_data["dob"].encode()).decode(),
        "diagnosis": cipher.encrypt(patient_data["diagnosis"].encode()).decode()
    }
    db.patients.insert(encrypted_data)

Adaptations and Context-Awareness
Cursor will adjust security and compliance recommendations based on:
Application Type:
Web: Focus on OWASP Top 10, secure headers.

Mobile: Recommend secure storage (e.g., Keychain for iOS).

API: Suggest rate limiting, API key management.

Desktop: Recommend secure update mechanisms.

Data Sensitivity:
Public: Minimal encryption, focus on availability.

Internal: Encrypt sensitive internal data.

Confidential (e.g., PII, health data): Strong encryption, access controls, audit logs.

Compliance: Tailor to regulations (e.g., GDPR, HIPAA).

Framework Capabilities:
Leverage built-in security features (e.g., Django’s CSRF protection).

Recommend security plugins (e.g., helmet for Express).

Suggest secure configuration options.

Deployment Environment:
Cloud: Use cloud-native security tools (e.g., AWS WAF).

On-Prem: Recommend firewall rules, network segmentation.

Containers: Suggest image scanning, least-privilege execution.

Serverless: Focus on function permissions, secure environment variables.

Authentication Methods:
OAuth/OIDC: Recommend token validation, scope checks.

Sessions: Suggest secure cookie settings, session timeouts.

API Keys: Recommend rotation, usage restrictions.

This document provides a robust foundation for Cursor to deliver precise, actionable, and context-aware security and compliance assistance across diverse software development scenarios.


