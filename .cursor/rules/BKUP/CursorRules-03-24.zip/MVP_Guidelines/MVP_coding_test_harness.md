Cursor Testing Guidelines - MVP Version
These guidelines instruct Cursor on providing automated test harness support for a Node.js/TypeScript project (using Jest) and a Python project (using pytest), both with MVC-like architectures. Cursor should detect the project’s language and framework, then apply these rules to generate tests, configurations, and utilities.
1. Base Test Configuration
Node.js/TypeScript (Jest)
Jest Configuration:
Generate a jest.config.ts file with TypeScript support.

Test Environment:
Use mongodb-memory-server for in-memory MongoDB testing.

Global Setup/Teardown:
Create a setup.ts file for Jest hooks.

Example:
typescript

// jest.config.ts
import type { Config } from 'jest';

const config: Config = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  setupFilesAfterEnv: ['<rootDir>/test/setup.ts'],
  coverageDirectory: 'coverage',
  collectCoverage: true,
  coverageThreshold: {
    global: { branches: 80, functions: 80, lines: 80, statements: 80 }
  }
};

export default config;

// test/setup.ts
import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';

let mongoServer: MongoMemoryServer;

beforeAll(async () => {
  mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri());
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoServer.stop();
});

Python (pytest)
Configuration:
Generate a conftest.py file for pytest fixtures.

Test Environment:
Use SQLAlchemy with an in-memory SQLite database for testing.

Global Setup:
Define a database fixture.

Example:
python

# conftest.py
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from app.database import Base

@pytest.fixture(scope="function")
def db_session():
    """Create an in-memory SQLite database for testing."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    session = Session(engine)
    yield session
    session.close()
    Base.metadata.drop_all(engine)

2. Unit Test Templates
Node.js/TypeScript (Jest)
Model:

typescript

// src/models/user.test.ts
import { UserModel } from './user';

describe('UserModel', () => {
  it('validates email format', () => {
    const validUser = { email: 'test@example.com', name: 'Test' };
    expect(() => UserModel.validate(validUser)).not.toThrow();
    
    const invalidUser = { email: 'invalid', name: 'Test' };
    expect(() => UserModel.validate(invalidUser)).toThrow('Invalid email');
  });
});

Controller:

typescript

// src/controllers/user.test.ts
import { UserController } from './user';
import { mockRequest, mockResponse } from 'jest-mock-express';

describe('UserController', () => {
  it('creates a user', async () => {
    const req = mockRequest({ body: { email: 'test@example.com' } });
    const res = mockResponse();
    await UserController.create(req, res);
    expect(res.status).toHaveBeenCalledWith(201);
  });
});

Service:

typescript

// src/services/user.test.ts
import { UserService } from './user';
import { mock } from 'jest-mock-extended';

describe('UserService', () => {
  it('fetches user by ID', async () => {
    const dbMock = mock<{ findById: jest.Mock }>();
    dbMock.findById.mockResolvedValue({ id: 1 });
    const result = await UserService.getUser(1, dbMock);
    expect(result).toEqual({ id: 1 });
  });
});

Python (pytest)
Model:

python

# tests/models/test_user.py
from app.models.user import User

def test_user_validation(db_session):
    """Test user model validation."""
    user = User(email="test@example.com", full_name="Test")
    db_session.add(user)
    db_session.commit()
    assert user.email == "test@example.com"

Controller:

python

# tests/controllers/test_user.py
from app.controllers.user import create_user

def test_create_user(mocker):
    """Test user creation controller."""
    db_mock = mocker.patch('app.controllers.user.get_db')
    request = {"email": "test@example.com"}
    response = create_user(request, db_mock)
    assert response["status"] == 201

Service:

python

# tests/services/test_user.py
from app.services.user import UserService

def test_get_user(mocker):
    """Test user retrieval service."""
    db_mock = mocker.patch('app.services.user.get_db')
    db_mock.query.return_value.filter.return_value.first.return_value = {"id": 1}
    result = UserService.get_user(1, db_mock)
    assert result["id"] == 1

3. Integration Test Templates
Node.js/TypeScript (Jest)
API Endpoint:

typescript

// src/routes/user.test.ts
import supertest from 'supertest';
import app from '../app';

describe('User API', () => {
  it('GET /users returns users', async () => {
    const response = await supertest(app).get('/users');
    expect(response.status).toBe(200);
    expect(response.body).toBeInstanceOf(Array);
  });
});

Python (pytest)
API Endpoint:

python

# tests/integration/test_user_api.py
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_get_users(db_session):
    """Test retrieving users via API."""
    response = client.get("/users/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

4. Test Helpers and Utilities
Node.js/TypeScript (Jest)
Mock Data:

typescript

// test/helpers.ts
export const mockUser = () => ({
  email: `test${Math.random()}@example.com`,
  name: 'Test User'
});

Python (pytest)
Mock Data:

python

# tests/utils.py
import random
import string

def random_string(length=10):
    """Generate a random string."""
    return ''.join(random.choices(string.ascii_lowercase, k=length))

def mock_user():
    """Generate mock user data."""
    return {"email": f"{random_string()}@example.com", "full_name": "Test"}

5. Test Coverage Configuration
Node.js/TypeScript (Jest)
Coverage is enabled in jest.config.ts (see Base Configuration).

Python (pytest)
Configuration:

ini

# pytest.ini
[pytest]
addopts = --cov=app --cov-report=html --cov-fail-under=80

6. CI/CD Integration
Node.js/TypeScript (Jest)
GitHub Actions Workflow:

yaml

# .github/workflows/test.yml
name: Node.js Tests
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm ci
      - run: npm test

Python (pytest)
GitHub Actions Workflow:

yaml

# .github/workflows/test.yml
name: Python Tests
on: [push]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.9'
      - run: pip install poetry
      - run: poetry install
      - run: poetry run pytest

This MVP version provides Cursor with a solid foundation for test harnesses in both Node.js/TypeScript and Python, covering all requested areas in a concise, actionable way. Let me know if you’d like to expand it further or adjust its placement!


