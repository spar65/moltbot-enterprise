# Cursor Operations & Incident Management Guidelines - MVP Version

This document provides the minimal, essential rules for Cursor to support operational tasks and incident management, focusing on alerting, incident response, and basic resilience.

---

## 1. Alerting Implementation

- **Detect Monitoring Tools**: Identify monitoring systems (e.g., Prometheus, Datadog) in the codebase.
- **Generate Basic Alerts**: Create alerts for critical issues (e.g., HTTP 5xx errors >1%).
- **Flag Missing Alerts**: Highlight critical functions without alerts (e.g., payment processing).

---

## 2. Incident Response Automation

- **Generate Runbook Snippets**: Provide commands for common issues (e.g., `tail -f /var/log/app.log`).
- **Identify Automation Opportunities**: Suggest automating repetitive tasks (e.g., service restarts).
- **Classify Severity**: Label incidents as P1 (critical) or P2 (high) based on impact.

---

## 3. Post-Incident Analysis

- **Generate Post-Mortem Templates**: Include sections for Summary, Root Cause, and Action Items.
- **Track Corrective Actions**: Suggest tracking fixes (e.g., in a comment or Markdown file).

---

## 4. Operational Communication

- **Suggest Communication Tools**: Recommend tools like Slack for incident channels.
- **Provide Update Templates**: Offer basic templates (e.g., "Investigating issue").

---

## 5. Resilience Improvement

- **Flag Single Points of Failure**: Identify critical components without redundancy.
- **Suggest Basic Metrics**: Recommend monitoring error rates and latency.

---

## Implementation Examples

### Basic Alert Configuration
```python
from prometheus_client import Counter

PAYMENT_FAILURES = Counter('payment_failures_total', 'Total payment failures')

def process_payment(payment_data):
    try:
        result = payment_service.charge(payment_data)
        return result
    except Exception as e:
        PAYMENT_FAILURES.inc()
        logger.error(f"Payment failed: {str(e)}")
        return None

Simple Runbook Snippet
bash

# Check logs for errors
tail -f /var/log/payment.log
# Restart service if needed
systemctl restart payment

This MVP ensures Cursor delivers critical support for operations and incident management with simplicity and immediate value.


