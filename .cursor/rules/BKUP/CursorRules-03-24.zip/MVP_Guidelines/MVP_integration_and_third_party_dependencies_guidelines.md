Cursor Integration & Third-Party Dependencies Guidelines - MVP Version
These guidelines outline the minimal rules for Cursor to assist with integration patterns and third-party dependency management. The focus is on critical, easy-to-implement actions that deliver immediate value.
1. Integration Pattern Assistance
Detect and Flag Undocumented Integrations:
Cursor scans the codebase for external service integrations (e.g., API clients) and flags any that lack documentation or standardization, alerting the user to potential issues.

2. Secret Management
Detect Hardcoded Credentials:
Cursor identifies hardcoded API keys or credentials and suggests replacing them with environment variables (e.g., os.getenv() in Python or process.env in JavaScript) for better security.

3. Dependency Version Management
Identify Unpinned Dependencies:
Cursor detects dependencies without specific version constraints (e.g., "express": "^4.17.1") and recommends pinning them to exact versions (e.g., "express": "4.17.1") to ensure stability.

4. Adaptations and Context-Awareness
Detect Language and Framework:
Cursor infers the programming language and framework (e.g., Python with Django, JavaScript with Express) from the codebase to tailor its suggestions to the environment.

This MVP version provides a strong foundation for Cursor’s automation capabilities, focusing on detection and basic recommendations. It ensures critical support for integration and dependency management while remaining simple and user-friendly. More advanced features can be added in future iterations as needed. Let me know if you’d like any tweaks!


