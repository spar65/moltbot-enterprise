# Cursor Coding Pattern & Guidelines - MVP Version

This document outlines the minimal essential guidelines for Cursor to follow when analyzing, suggesting, and generating code. These rules focus on fundamental coding practices and are designed to ensure basic functionality and code quality.

---

## Core Principles

- **Always prefer simple solutions**: Recommend clarity and minimal complexity in code suggestions.
- **Avoid duplication of code**: Identify and recommend refactoring duplicated code patterns.
- **Make only requested or clearly understood changes**: Limit recommendations to the specific task at hand.
- **Use existing patterns before introducing new ones**: Prioritize consistency with the established codebase.
- **Keep the codebase very clean and organized**: Recommend proper organization and cleanliness.

---

## AI-Assisted Coding Guidelines

### 1. Code Style & Consistency
- Recommend fixes for style violations using detected standards (e.g., PEP 8 for Python).
- Recommend descriptive and consistent naming conventions.

### 2. Testing Suggestions
- Recommend tests for new code and untested paths.
- Use appropriate testing frameworks based on the project.

### 3. Error Handling & Logging
- Flag inadequate error handling and recommend improvements.
- Recommend consistent logging practices.

### 4. Security Enhancement
- Detect hardcoded secrets and recommend using environment variables.
- Recommend input validation and sanitization to prevent common vulnerabilities.

### 5. Context-Aware Assistance
- Learn from the codebase to provide recommendations aligned with project patterns.

---

## Implementation Examples

### Security Enhancement
```python
# Original code with hardcoded secret
API_KEY = "xyz123"

Cursor recommendation:
python

# Security issue: Hardcoded secret detected
# Use environment variables instead
import os
API_KEY = os.getenv("API_KEY", "default-key")

Testing Suggestions
When new functionality is added without tests:
Cursor recommendation:
python

# Recommend adding tests for the new function
def test_new_function():
    # Test case here
    pass

Code Style & Consistency
python

# Original code with inconsistent naming
def calc_total_price(items):
    total = 0
    for i in items:
        total += i.price
    return total

Cursor recommendation:
python

# Recommend consistent naming
def calculate_total_price(items):
    total_price = 0
    for item in items:
        total_price += item.price
    return total_price

---

This MVP version focuses on the critical essentials: simplicity, consistency, error handling, security, and context-aware assistance. You can copy this Markdown content directly into a `.md` or `.mdc` file using your preferred editor, like VI. Let me know if you need any tweaks!


