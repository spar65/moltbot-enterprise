# Cursor Technical Stack Guidelines - MVP Version

This MVP version outlines the essential rules for Cursor to support the project's technical stack: Python (FastAPI), React, PostgreSQL (SQLAlchemy), and Docker.

---

## 1. Backend (Python)
- **Recognize Python and FastAPI**:
  - Detect Python files and recommend FastAPI as the framework.
- **Code Style**:
  - Enforce 4-space indentation (PEP 8 basics).

---

## 2. Frontend (HTML/JS)
- **Recognize React**:
  - Detect React and suggest functional components with hooks.

---

## 3. Databases (SQL)
- **Recognize PostgreSQL and SQLAlchemy**:
  - Detect PostgreSQL and SQLAlchemy, suggest basic model definitions.

---

## 4. Deployment
- **Recognize Docker**:
  - Detect Docker and suggest basic usage.

---

## General Rules
- **Context-Awareness**:
  - Tailor suggestions to the detected language and framework.

---

## Examples

### FastAPI Endpoint
```python
from fastapi import FastAPI

app = FastAPI()

@app.get("/users")
def get_users():
    return {"message": "Users list"}

React Component
javascript

import React from 'react';

const MyComponent = () => {
  return <div>Hello, world!</div>;
};

export default MyComponent;

This version focuses on the bare essentials, ensuring Cursor provides critical support for the project's stack with simplicity and clarity.


