# Cursor Deployment & Infrastructure Guidelines - MVP Version

This document outlines the minimal essential rules for Cursor to assist with deployment, infrastructure, and operational tasks. It covers the basics of CI/CD, containerization, rollback, monitoring, logging, performance, infrastructure as code (IaC), and disaster recovery, ensuring functionality and reliability for small or starting projects.

---

## 1. Deployment Strategy Assistance

- Identify existing CI/CD configurations (e.g., GitHub Actions, Jenkins).
- Suggest basic improvements to build and deployment workflows (e.g., adding a test step).
- Flag missing critical steps in deployment pipelines (e.g., no testing or security scanning).
- Recommend simple containerization (e.g., basic Dockerfile for the application).
- Suggest moving hardcoded environment values to environment variables.

---

## 2. Rollback Mechanism Support

- Suggest a basic rollback strategy (e.g., redeploy the previous version).
- Flag deployments that lack any rollback mechanism.
- Recommend testing rollback procedures manually before critical deployments.

---

## 3. Monitoring Implementation

- Identify a basic monitoring tool (e.g., Prometheus for metrics).
- Suggest adding a health check endpoint (e.g., `/health` for web services).
- Recommend monitoring essential metrics (e.g., response time, error rate).

---

## 4. Logging Enhancement

- Identify inconsistent logging patterns and suggest using structured logging.
- Recommend standardized log levels (e.g., INFO, ERROR).
- Flag logs containing sensitive data (e.g., passwords, API keys).

---

## 5. Performance Metrics & Optimization

- Suggest tracking critical performance indicators (e.g., CPU usage, memory).
- Recommend basic optimizations (e.g., caching frequent queries).
- Flag obvious performance bottlenecks (e.g., unindexed database queries).

---

## 6. Infrastructure-as-Code Support

- Provide simple IaC templates (e.g., basic Terraform for cloud resources).
- Flag insecure configurations (e.g., open security groups, excessive permissions).

---

## 7. Disaster Recovery Planning

- Suggest a basic backup strategy for critical data (e.g., daily database backups).
- Flag critical data or services without any backup procedures.

---

## Examples

### Basic CI/CD Pipeline Suggestion
```yaml
# Suggested simple GitHub Actions workflow
name: Build and Deploy

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build
        run: docker build -t myapp .
      - name: Test
        run: docker run myapp npm test
      - name: Deploy
        run: ./deploy.sh

Simple Dockerfile Recommendation
dockerfile

# Basic Dockerfile for a Python app
FROM python:3.9-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
CMD ["python", "app.py"]

This MVP rules file ensures Cursor provides critical support for deployment and infrastructure tasks with simplicity and immediate usability. It’s perfect for getting started quickly!


