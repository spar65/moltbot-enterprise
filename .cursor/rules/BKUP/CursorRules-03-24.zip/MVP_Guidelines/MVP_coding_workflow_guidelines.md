# Cursor Workflow Rules - MVP Version

This page outlines the minimal, critical rules for Cursor to succeed in supporting development workflows. These focus on branching, pull requests, testing, and documentation to maintain code quality and streamline collaboration.

---

## 1. Branching Rules

- **No Direct Commits to Main**: Work must occur in feature branches (e.g., `feature/add-login`).
- **Consistent Naming**: Use prefixes like `feature/`, `bugfix/`, or `hotfix/` for branch names.
- **Clear Commit Messages**: Include issue references (e.g., `Add login endpoint #123`).

---

## 2. Pull Request Rules

- **Run Tests Before Submission**: Ensure all tests pass before creating a PR.
- **Clean Code**: Remove `TODO` comments and debug code (e.g., `console.log`).
- **PR Description**: Include a summary, changes, and testing details.

---

## 3. Testing Rules

- **Test New Code**: All new functionality must have tests (e.g., unit or integration).
- **Cover Edge Cases**: Include tests for unexpected inputs or failures.
- **CI/CD Integration**: Tests must run in automated pipelines.

---

## 4. Documentation Rules

- **Update Docs with Changes**: Reflect code changes in technical docs or `README`.
- **Summarize Changes**: Provide brief release notes or change summaries.

---

## Examples

### Branching

Command: git checkout -b feature/add-login
Commit: git commit -m "Add login endpoint #123"

### Pull Request

PR Title: Add User Login
Changes: Added login endpoint with JWT.
Testing: Verified valid/invalid inputs.

### Testing
```python
def test_login_failure():
    result = AuthService().login("user@example.com", "wrong")
    assert result is None

Documentation

API Update:
- POST /login: Returns JWT token on success.

These rules ensure Cursor provides essential support for development success, keeping workflows efficient and code reliable.


