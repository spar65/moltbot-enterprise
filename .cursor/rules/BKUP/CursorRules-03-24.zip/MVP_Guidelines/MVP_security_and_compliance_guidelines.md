# Cursor Security & Compliance Guidelines - MVP Version

This document provides the minimal essential guidelines for Cursor to assist with security and compliance in software development, focusing on core areas like code security, dependencies, and basic compliance.

---

## 1. Security Review Assistance

- Flag hardcoded credentials (e.g., API keys, passwords).
- Suggest avoiding unsafe practices (e.g., raw SQL with user input).

---

## 2. Dependency Management

- Identify outdated or vulnerable dependencies.
- Suggest updating to secure versions.

---

## 3. Vulnerability Remediation

- Suggest fixes for common issues (e.g., use parameterized SQL, hash passwords).

---

## 4. Compliance Support

- Recommend encrypting sensitive data (e.g., PII).
- Suggest logging access to sensitive data.

---

## 5. Authentication & Authorization

- Suggest secure authentication (e.g., avoid basic auth).
- Recommend authorization checks for resource access.

---

## 6. Data Protection

- Suggest encrypting sensitive data (e.g., passwords).
- Recommend validating user inputs.

---

## Implementation Examples

### SQL Injection Prevention
```python
# Vulnerable
query = f"SELECT * FROM users WHERE username = '{username}'"

Fix:
python

# Secure
query = "SELECT * FROM users WHERE username = %s"
cursor.execute(query, (username,))

Secure Password Storage
javascript

// Vulnerable
const user = { username, password };

Fix:
javascript

// Secure
const hashedPassword = await bcrypt.hash(password, 12);
const user = { username, password: hashedPassword };

Adaptations
Adjust advice based on app type and data sensitivity.

This is the leanest version of the guidelines, focusing only on the must-haves for security and compliance.


