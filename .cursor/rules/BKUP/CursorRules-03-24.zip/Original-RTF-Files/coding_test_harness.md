
Node.js/TypeScript Test Harness

Create a complete test harness for my Node.js/TypeScript project using Jest. The project follows a typical MVC architecture with controllers, services, models, and routes. Include the following:

1. Base test configuration:
   - Jest configuration file with TypeScript support
   - Test environment setup for MongoDB using mongodb-memory-server
   - Global test setup and teardown hooks

2. Unit test templates for:
   - Models (with validation tests)
   - Controllers (with request/response mocking)
   - Services (with dependency mocking)
   - Utilities and helper functions

3. Integration test templates for:
   - API endpoints (with supertest)
   - Database operations
   - Authentication flows

4. Test helpers and utilities:
   - Mock data generation functions
   - Request/response mocking utilities
   - Authentication test helpers
   - Database seeding utilities

5. Test coverage configuration:
   - Setup Jest to collect coverage information
   - Coverage thresholds configuration
   - Coverage reporting setup

6. CI/CD integration:
   - GitHub Actions workflow for running tests
   - Test reporting and badge setup

All code should follow best practices for testing, including proper use of describe/it blocks, beforeEach/afterEach hooks, and error handling. Include comments explaining testing strategies and patterns.

Create a complete test harness for my Python project using pytest. The project follows a typical architecture with models, views, controllers/services, and utilities. Include the following:

1. Base test configuration:
   - pytest configuration file (pytest.ini or conftest.py)
   - Test environment setup for database testing using pytest-django or SQLAlchemy fixtures
   - Global test fixtures and plugins

2. Unit test templates for:
   - Models (with validation tests)
   - Views/Controllers (with request/response mocking)
   - Services (with dependency mocking)
   - Utilities and helper functions

3. Integration test templates for:
   - API endpoints (with pytest-flask, pytest-django, or similar)
   - Database operations
   - Authentication flows

4. Test helpers and utilities:
   - Fixture factories using factory_boy or similar
   - Mock data generation functions
   - Request/response mocking utilities using pytest-mock
   - Authentication test helpers
   - Database test fixtures

5. Test coverage configuration:
   - Setup pytest-cov to collect coverage information
   - Coverage thresholds configuration
   - Coverage reporting setup

6. CI/CD integration:
   - GitHub Actions workflow for running tests
   - Test reporting and badge setup
   - tox configuration for testing across multiple Python versions

All code should follow Python best practices for testing, including proper use of pytest fixtures, parametrization, and markers. Include docstrings explaining testing strategies and patterns.
