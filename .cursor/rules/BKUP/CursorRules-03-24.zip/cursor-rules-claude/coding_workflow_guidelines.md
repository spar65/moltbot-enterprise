# Cursor Workflow Guidelines

These guidelines instruct Cursor how to interact with workflow processes when assisting with development tasks. They define how Cursor should approach branching, code reviews, testing, and other collaborative aspects of software development.

---

## 1. Branching and Version Control

### Feature Branch Detection & Suggestion

**Branch Creation Assistance:**
- Detect when work appears to be happening on main/master branch
- Proactively suggest creating a feature branch for new work
- Provide branch creation commands when appropriate
- Generate branch names following project conventions

**Naming Convention Enforcement:**
- Suggest consistent branch naming patterns (e.g., `feature/xxx`, `bugfix/xxx`)
- Detect project-specific branch naming conventions and apply them
- Recommend standardized prefixes based on work type (feature, bugfix, hotfix)
- Alert when branch names don't follow established patterns

**Commit Message Guidance:**
- Suggest clear, structured commit messages explaining the "why" behind changes
- Detect project commit message conventions (e.g., conventional commits)
- Recommend including issue/ticket references when appropriate
- Help structure commit messages with subject line and detailed body when needed

---

## 2. Pull Request & Code Review Assistance

### PR Preparation

**Pre-Submission Checks:**
- Suggest running tests before PR submission
- Scan for unresolved TODO comments, debug code, or console logs
- Check for unrelated changes that should be in separate PRs
- Verify documentation is updated along with code changes

**PR Template Generation:**
- Offer to generate descriptive PR descriptions
- Include summaries of changes with rationale
- List affected modules or components
- Add testing notes and verification steps

### Code Review Support

**Review Checklist Application:**
- Apply standard review checklist to code changes
- Verify adherence to coding standards and patterns
- Check for proper test coverage
- Assess potential impact on related components

**Collaborative Feedback:**
- Frame suggestions constructively and explain rationale
- Provide alternative approaches with pros/cons
- Focus on code improvement rather than criticism
- Use clear, specific language in review comments

---

## 3. Testing & Quality Assurance Integration

### Test Generation

**Test Coverage Analysis:**
- Identify untested code and suggest test coverage
- Generate test templates for new functionality
- Suggest appropriate test types (unit, integration, end-to-end)
- Recommend test cases for edge conditions and failure modes

**Test Framework Integration:**
- Detect and utilize project's testing framework
- Generate tests consistent with existing patterns
- Suggest appropriate test locations and naming conventions
- Provide setup and teardown code when needed

### Test-Driven Development Support

**TDD Workflow Assistance:**
- Offer to generate failing tests before implementation
- Guide through red-green-refactor cycle
- Suggest minimal implementations to make tests pass
- Recommend refactoring opportunities after tests pass

**Test Quality Enhancement:**
- Identify brittle tests and suggest improvements
- Recommend test isolation practices
- Suggest appropriate mocking strategies
- Flag tests that might be testing implementation rather than behavior

---

## 4. Change Management

### Change Isolation

**Focused Change Detection:**
- Alert when changes appear to affect unrelated code areas
- Suggest limiting scope of changes to relevant components
- Help identify minimum necessary changes for a task
- Recommend separate branches for unrelated improvements

**Impact Analysis:**
- Analyze potential side effects of changes
- Identify dependent components that might be affected
- Suggest additional tests for potentially impacted areas
- Help document findings about wider system impact

### Feature Toggle Support

**Toggle Implementation:**
- Suggest feature toggle patterns appropriate to the codebase
- Generate toggle configuration code
- Recommend toggle cleanup after feature stabilization
- Provide examples of gradual rollout strategies using toggles

**Toggle Management:**
- Track feature toggles within the codebase
- Suggest consolidation of related toggles
- Alert about potentially forgotten or outdated toggles
- Help document toggle purposes and conditions

---

## 5. Documentation & Communication

### Documentation Updates

**Documentation Synchronization:**
- Detect when code changes require documentation updates
- Suggest specific documentation changes to match code
- Generate or update technical documentation
- Ensure API documentation reflects current implementation

**README & Guide Management:**
- Alert when significant changes should be reflected in README
- Suggest updates to developer setup instructions when dependencies change
- Help maintain architecture diagrams and design documents
- Generate end-user documentation for new features

### Communication Support

**Change Summaries:**
- Generate summaries of implemented changes
- Create release notes from commit history
- Prepare implementation notes for team communication
- Summarize breaking changes and migration steps

**Knowledge Sharing:**
- Suggest documentation of non-obvious design decisions
- Help create explanations of complex algorithms or workflows
- Generate examples demonstrating usage of new features
- Prepare technical presentations or demonstrations when requested

---

## 6. Workflow Improvement

### Process Enhancement

**Workflow Analysis:**
- Identify repetitive tasks that could be automated
- Suggest improvements to development workflow
- Detect common friction points in development process
- Recommend tooling improvements

**Automation Opportunities:**
- Generate scripts for common development tasks
- Suggest CI/CD pipeline improvements
- Recommend static analysis and linting configurations
- Help set up automated quality checks

### Learning & Adaptation

**Project Pattern Recognition:**
- Analyze project workflow patterns and adapt suggestions
- Learn from accepted vs. rejected recommendations
- Adjust to team-specific processes and preferences
- Maintain awareness of project-specific conventions

**Continuous Enhancement:**
- Suggest process improvements based on observed patterns
- Adapt to changing project requirements and structures
- Evolve recommendations based on project maturity
- Incorporate industry best practices appropriate to project context

---

## Implementation Examples

### Branch Creation Assistance

> When detecting new feature work on main branch:

```
It appears you're implementing a new feature directly on the main branch.
Would you like me to help create a feature branch for this work?

Suggested branch name: feature/user-authentication
Command: git checkout -b feature/user-authentication
```

---

### PR Description Generation

> When preparing for a pull request:

```
# Add user authentication system

## Changes
- Implement JWT-based authentication 
- Add login and registration endpoints
- Create middleware for protected routes
- Add user model and database schema

## Testing
- Verified login success/failure paths
- Tested token validation and expiration
- Confirmed middleware properly restricts access

## Notes
- Database migration will be required
- Frontend components will need to be updated to use auth tokens
```

---

### Test Generation

> When new functionality is added without tests:

```python
import pytest
from app.services import UserService

class TestUserService:
    def test_create_user_success(self):
        # Given
        service = UserService()
        user_data = {"username": "testuser", "email": "test@example.com"}
        
        # When
        result = service.create_user(user_data)
        
        # Then
        assert result["id"] is not None
        assert result["username"] == "testuser"
    
    def test_create_user_duplicate_username(self):
        # Given
        service = UserService()
        user_data = {"username": "existing_user", "email": "new@example.com"}
        
        # When/Then
        with pytest.raises(ValueError) as excinfo:
            service.create_user(user_data)
        assert "Username already exists" in str(excinfo.value)
```

---

### Feature Toggle Suggestion

> When implementing a feature that might need gradual rollout:

```javascript
// Feature toggle implementation
const FEATURES = {
  newPaymentProcessor: process.env.ENABLE_NEW_PAYMENT_PROCESSOR === 'true'
};

// Usage
if (FEATURES.newPaymentProcessor) {
  // New implementation
  return processPaymentV2(paymentData);
} else {
  // Existing implementation
  return processPayment(paymentData);
}
```

This allows you to:
- Deploy the code without activating the feature
- Test in production with limited exposure
- Gradually roll out to users
- Quickly disable if issues arise

---

## Adaptations and Context-Awareness

Cursor will adjust these workflow recommendations based on project context, including:

1. **Repository Size and Structure**
   - Simpler guidance for small projects
   - More formal processes for larger codebases

2. **Team Size Indicators**
   - More structured approach for multi-contributor projects
   - Streamlined suggestions for solo development

3. **Project Maturity**
   - Progressive introduction of advanced practices for newer projects
   - Full workflow support for established codebases

4. **Observed Patterns**
   - Adaptation to team's established workflows
   - Respect for existing conventions and processes

5. **Framework-Specific Workflows**
   - Tailored suggestions for specific frameworks (React, Django, etc.)
   - Framework-appropriate testing and deployment recommendations