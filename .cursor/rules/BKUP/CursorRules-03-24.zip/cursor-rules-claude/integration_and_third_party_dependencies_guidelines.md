# Cursor Integration & Third-Party Dependencies Guidelines

These guidelines instruct Cursor how to assist with integration patterns and third-party dependency management. They define how Cursor should analyze, suggest, and help implement external service integrations and dependency management in codebases.

---

## Integration Pattern Assistance

### Integration Documentation

**Integration Detection:**
- Identify external service integrations in codebases
- Detect API clients and integration points
- Flag undocumented integration patterns
- Recognize common integration libraries and frameworks

**Documentation Generation:**
- Generate documentation templates for external integrations
- Suggest standardized documentation formats for API integrations
- Create endpoint catalogs for service dependencies
- Recommend authentication documentation patterns

**Usage Example Creation:**
- Generate code examples for service integrations
- Provide usage patterns for external APIs
- Create test cases demonstrating integration patterns
- Suggest integration test approaches

---

## Integration Standardization

### Pattern Consistency

**Pattern Recognition:**
- Identify inconsistent integration approaches within a codebase
- Detect different patterns for similar external services
- Recognize non-standard error handling for integrations
- Flag divergent authentication implementations

**Standardization Recommendations:**
- Suggest unified API client implementation patterns
- Recommend abstraction layers for similar services
- Generate adapter patterns for consistent interfaces
- Propose service interface standardization

**Migration Assistance:**
- Create migration plans for standardizing integrations
- Generate code for transitioning to consistent patterns
- Suggest incremental approaches to standardization
- Provide compatibility layers during transitions

---

## Secret Management

### API Key Security

**Secret Detection:**
- Identify hardcoded API keys and credentials
- Detect insecure secret storage patterns
- Flag credentials in configuration files
- Recognize inadequate secret handling

**Secure Implementation:**
- Suggest environment variable approaches for credentials
- Recommend secret management tools appropriate to the stack
- Generate secure credential loading patterns
- Provide examples of secret rotation implementation

**Documentation Support:**
- Create credential management documentation templates
- Generate secret rotation procedure documentation
- Suggest access control patterns for credentials
- Recommend audit logging for credential usage

---

## Dependency Reliability

### Monitoring Implementation

**Service Health Tracking:**
- Suggest monitoring patterns for external dependencies
- Generate health check implementations
- Recommend circuit breaker patterns
- Provide retry strategy implementations

**Performance Instrumentation:**
- Create instrumentation for dependency performance tracking
- Suggest latency and error tracking implementations
- Generate dashboard configurations for dependency monitoring
- Recommend alert thresholds for integration issues

**Reliability Pattern Suggestions:**
- Suggest fallback mechanisms for unreliable dependencies
- Recommend caching strategies where appropriate
- Generate graceful degradation approaches
- Propose resilience patterns for critical dependencies

---

## Dependency Version Management

### Version Control

**Version Pinning:**
- Identify unpinned dependencies
- Suggest specific version constraints
- Flag overly loose version specifications
- Recommend version management strategies

**Update Assistance:**
- Generate update testing strategies
- Suggest incremental update approaches
- Flag breaking changes in dependency updates
- Provide compatibility testing approaches

**Documentation Generation:**
- Create dependency version documentation templates
- Generate migration guides for major updates
- Suggest changelog tracking mechanisms
- Recommend version policy documentation

---

## Implementation Examples

Example: API Client Standardization
When detecting inconsistent API client implementation:
# Original inconsistent implementations
def call_payment_api(data):
    url = "https://payment.example.com/api/v1/charge"
    headers = {"Authorization": "Bearer " + os.environ.get("PAYMENT_API_KEY")}
    response = requests.post(url, json=data, headers=headers)
    return response.json()

def get_shipping_info(order_id):
    base_url = "https://shipping.example.com/api"
    api_key = os.environ.get("SHIPPING_API_KEY")
    endpoint = f"/orders/{order_id}/tracking"
    r = requests.get(base_url + endpoint, auth=(api_key, ""))
    if r.status_code == 200:
        return r.json()
    else:
        raise Exception(f"Shipping API error: {r.status_code}")
Cursor suggestion:
# Standardized API client pattern
class ApiClient:
    """Base API client to standardize external service integration patterns.
    
    This provides consistent handling for:
    - Authentication
    - Error handling
    - Logging
    - Timeout configuration
    - Retry behavior
    """
    def __init__(self, base_url, auth_type="bearer", timeout=10, max_retries=3):
        self.base_url = base_url.rstrip('/')
        self.auth_type = auth_type
        self.timeout = timeout
        self.session = requests.Session()
        self.session.mount('https://', requests.adapters.HTTPAdapter(max_retries=max_retries))
        
    def _get_auth_header(self, api_key):
        """Standardized auth header generation based on auth type."""
        if self.auth_type == "bearer":
            return {"Authorization": f"Bearer {api_key}"}
        elif self.auth_type == "basic":
            return {"Authorization": f"Basic {base64.b64encode(f'{api_key}:'.encode()).decode()}"}
        elif self.auth_type == "api_key":
            return {"X-API-Key": api_key}
        else:
            raise ValueError(f"Unsupported auth type: {self.auth_type}")
    
    def request(self, method, endpoint, api_key, data=None, params=None):
        """Make a request to the API with standardized error handling and logging."""
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = self._get_auth_header(api_key)
        
        # Add request correlation ID for tracing
        request_id = str(uuid.uuid4())
        headers["X-Request-ID"] = request_id
        
        logger.info(f"API request initiated", extra={
            "service": self.base_url,
            "endpoint": endpoint,
            "method": method,
            "request_id": request_id
        })
        
        start_time = time.time()
        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                json=data if method in ["POST", "PUT", "PATCH"] else None,
                params=params,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            # Log successful response
            duration = time.time() - start_time
            logger.info(f"API request successful", extra={
                "service": self.base_url,
                "endpoint": endpoint,
                "method": method,
                "status_code": response.status_code,
                "duration_ms": int(duration * 1000),
                "request_id": request_id
            })
            
            return response.json()
        except requests.exceptions.HTTPError as e:
            duration = time.time() - start_time
            logger.error(f"API request failed with status {e.response.status_code}", extra={
                "service": self.base_url,
                "endpoint": endpoint,
                "method": method,
                "status_code": e.response.status_code,
                "duration_ms": int(duration * 1000),
                "request_id": request_id,
                "response_body": e.response.text[:500]  # Truncate long responses
            })
            raise ApiError(f"API error: {e.response.status_code}", 
                          status_code=e.response.status_code,
                          response=e.response.text,
                          request_id=request_id)
        except requests.exceptions.ConnectionError:
            logger.error(f"API connection error", extra={
                "service": self.base_url,
                "endpoint": endpoint,
                "method": method,
                "request_id": request_id
            })
            raise ApiConnectionError(f"Failed to connect to {self.base_url}")
        except requests.exceptions.Timeout:
            logger.error(f"API timeout error", extra={
                "service": self.base_url,
                "endpoint": endpoint,
                "method": method,
                "timeout": self.timeout,
                "request_id": request_id
            })
            raise ApiTimeoutError(f"Request to {url} timed out after {self.timeout}s")


# Standard error classes for API interactions
class ApiError(Exception):
    """Base class for API errors with standardized attributes."""
    def __init__(self, message, status_code=None, response=None, request_id=None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response
        self.request_id = request_id


class ApiConnectionError(ApiError):
    """Raised when connection to the API fails."""
    pass


class ApiTimeoutError(ApiError):
    """Raised when API request times out."""
    pass


# Implementations using the standardized pattern
class PaymentApiClient(ApiClient):
    """Client for the Payment API."""
    def __init__(self):
        super().__init__(
            base_url="https://payment.example.com/api/v1",
            auth_type="bearer",
            timeout=15  # Payments may take longer
        )
    
    def charge(self, data):
        """Process a payment charge."""
        api_key = os.environ.get("PAYMENT_API_KEY")
        return self.request("POST", "/charge", api_key, data=data)
        

class ShippingApiClient(ApiClient):
    """Client for the Shipping API."""
    def __init__(self):
        super().__init__(
            base_url="https://shipping.example.com/api",
            auth_type="basic",
            max_retries=2
        )
    
    def get_tracking(self, order_id):
        """Get tracking information for an order."""
        api_key = os.environ.get("SHIPPING_API_KEY")
        return self.request("GET", f"/orders/{order_id}/tracking", api_key)


# Updated function implementations
def call_payment_api(data):
    client = PaymentApiClient()
    return client.charge(data)

def get_shipping_info(order_id):
    client = ShippingApiClient()
    return client.get_tracking(order_id)
Example: Secret Management Implementation
When detecting hardcoded credentials:
// Original code with hardcoded credentials
const stripe = require('stripe')('sk_test_abcdefghijklmnopqrstuvwxyz123456');

function createCharge(amount, currency, description) {
  return stripe.charges.create({
    amount,
    currency,
    description,
    source: 'tok_visa'
  });
}

module.exports = { createCharge };
Cursor suggestion:
// Secure credential management implementation
const stripe = require('stripe');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

// Credential management options
class SecretManager {
  /**
   * Load secrets from the appropriate source based on environment
   * @returns {Object} key-value pairs of secrets
   */
  static getSecrets() {
    // Check for secrets manager in production
    if (process.env.NODE_ENV === 'production') {
      return SecretManager.getSecretsFromVault();
    }
    
    // Use .env file for development
    return SecretManager.getSecretsFromDotEnv();
  }
  
  /**
   * Load secrets from .env file (development environment)
   * @returns {Object} secrets from .env file
   */
  static getSecretsFromDotEnv() {
    // Load from .env file
    const result = dotenv.config();
    
    if (result.error) {
      console.warn('Error loading .env file, falling back to process.env');
    }
    
    return process.env;
  }
  
  /**
   * Load secrets from HashiCorp Vault (production environment)
   * @returns {Object} secrets from Vault
   */
  static getSecretsFromVault() {
    // This is a simplified example - in reality, you would:
    // 1. Use a proper Vault client library
    // 2. Handle authentication with Vault
    // 3. Implement caching and renewal of secrets
    try {
      // This is where you'd implement actual Vault interaction
      console.log('Fetching secrets from Vault');
      
      // For demonstration only - in production this would call Vault API
      return process.env;
    } catch (error) {
      console.error('Failed to fetch secrets from Vault', error);
      throw new Error('Could not load production secrets');
    }
  }
  
  /**
   * Get a specific secret, throwing an error if it's not found
   * @param {string} key - The secret key to retrieve
   * @returns {string} The secret value
   */
  static getSecret(key) {
    const secrets = SecretManager.getSecrets();
    
    if (!secrets[key]) {
      throw new Error(`Required secret "${key}" not found`);
    }
    
    return secrets[key];
  }
}

// Export a factory function that creates a properly configured client
function getStripeClient() {
  const apiKey = SecretManager.getSecret('STRIPE_API_KEY');
  return stripe(apiKey);
}

function createCharge(amount, currency, description) {
  const stripeClient = getStripeClient();
  return stripeClient.charges.create({
    amount,
    currency,
    description,
    source: 'tok_visa' // Note: in production, this would be a real token
  });
}

module.exports = { 
  createCharge,
  // Export the factory for testing with mocks
  getStripeClient
};
And suggest a .env.example file:
# API Keys - never commit actual keys to version control
STRIPE_API_KEY=sk_test_example
SHIPPING_API_KEY=example_key

# Stripe Configuration
STRIPE_WEBHOOK_SECRET=whsec_example
Example: Dependency Monitoring Implementation
When detecting unmonitored third-party dependencies:
# Original unmonitored HTTP client
import requests

def get_weather_data(location):
    """Get weather data for a location."""
    url = f"https://weather-api.example.com/current?location={location}"
    response = requests.get(url, timeout=5)
    response.raise_for_status()
    return response.json()
Cursor suggestion:
# Monitored HTTP client with circuit breaker pattern
import requests
import time
import logging
from prometheus_client import Counter, Histogram, Gauge
from circuitbreaker import circuit

# Set up monitoring metrics
EXTERNAL_REQUEST_DURATION = Histogram(
    'external_request_duration_seconds',
    'Time spent processing external API requests',
    ['service', 'endpoint', 'method', 'status']
)

EXTERNAL_REQUEST_FAILURES = Counter(
    'external_request_failures_total',
    'Number of external API request failures',
    ['service', 'endpoint', 'method', 'error_type']
)

EXTERNAL_REQUEST_CIRCUIT_STATE = Gauge(
    'external_request_circuit_state',
    'State of circuit breaker for external services (0=open, 1=closed, 0.5=half-open)',
    ['service']
)

# Configure logger
logger = logging.getLogger(__name__)

class MonitoredHttpClient:
    """HTTP client with monitoring, circuit breaking, and fallbacks."""
    
    def __init__(self, service_name, base_url=None, timeout=5, max_retries=3):
        self.service_name = service_name
        self.base_url = base_url.rstrip('/') if base_url else None
        self.timeout = timeout
        self.session = requests.Session()
        
        # Configure retries
        adapter = requests.adapters.HTTPAdapter(max_retries=max_retries)
        self.session.mount('http://', adapter)
        self.session.mount('https://', adapter)
        
        # Initialize circuit state metric
        EXTERNAL_REQUEST_CIRCUIT_STATE.labels(service=service_name).set(1)  # Start closed
    
    def _get_full_url(self, endpoint):
        """Construct full URL from base URL and endpoint."""
        if self.base_url:
            return f"{self.base_url}/{endpoint.lstrip('/')}"
        return endpoint
    
    @circuit(failure_threshold=5, recovery_timeout=30, name="http_request")
    def request(self, method, endpoint, **kwargs):
        """Make a monitored HTTP request with circuit breaking."""
        url = self._get_full_url(endpoint)
        timeout = kwargs.pop('timeout', self.timeout)
        
        # Update circuit state metric based on circuit breaker state
        # This would be tied to the actual circuit state in a real implementation
        circuit_state = 1  # 1=closed, 0=open, 0.5=half-open
        EXTERNAL_REQUEST_CIRCUIT_STATE.labels(service=self.service_name).set(circuit_state)
        
        start_time = time.time()
        status = "success"
        
        try:
            logger.info(f"Making {method} request to {self.service_name}: {endpoint}")
            response = self.session.request(method, url, timeout=timeout, **kwargs)
            response.raise_for_status()
            
            duration = time.time() - start_time
            EXTERNAL_REQUEST_DURATION.labels(
                service=self.service_name,
                endpoint=endpoint,
                method=method,
                status=status
            ).observe(duration)
            
            return response.json() if response.content else None
            
        except requests.exceptions.HTTPError as e:
            status = "error"
            EXTERNAL_REQUEST_FAILURES.labels(
                service=self.service_name,
                endpoint=endpoint,
                method=method,
                error_type="http_error"
            ).inc()
            
            logger.error(f"HTTP error from {self.service_name}: {e.response.status_code} - {url}")
            raise
            
        except requests.exceptions.ConnectionError:
            status = "error"
            EXTERNAL_REQUEST_FAILURES.labels(
                service=self.service_name,
                endpoint=endpoint,
                method=method,
                error_type="connection_error"
            ).inc()
            
            logger.error(f"Connection error connecting to {self.service_name}: {url}")
            raise
            
        except requests.exceptions.Timeout:
            status = "error"
            EXTERNAL_REQUEST_FAILURES.labels(
                service=self.service_name,
                endpoint=endpoint,
                method=method,
                error_type="timeout"
            ).inc()
            
            logger.error(f"Timeout from {self.service_name}: {url} ({timeout}s)")
            raise
            
        except Exception as e:
            status = "error"
            EXTERNAL_REQUEST_FAILURES.labels(
                service=self.service_name,
                endpoint=endpoint,
                method=method,
                error_type="unknown"
            ).inc()
            
            logger.error(f"Unknown error from {self.service_name}: {str(e)}")
            raise
            
        finally:
            # Always record duration even for failures
            if status == "error":
                duration = time.time() - start_time
                EXTERNAL_REQUEST_DURATION.labels(
                    service=self.service_name,
                    endpoint=endpoint,
                    method=method,
                    status=status
                ).observe(duration)


# Weather API client with fallback
class WeatherApiClient:
    """Client for the weather API with monitoring and fallback."""
    
    def __init__(self):
        self.client = MonitoredHttpClient(
            service_name="weather-api",
            base_url="https://weather-api.example.com",
            timeout=5
        )
        
        # Cache for fallback data
        self._cache = {}
    
    def get_current_weather(self, location):
        """Get current weather with fallback to cache."""
        try:
            data = self.client.request("GET", f"/current?location={location}")
            
            # Update cache with successful response
            self._cache[location] = {
                "data": data,
                "timestamp": time.time()
            }
            
            return data
        except Exception as e:
            logger.warning(f"Failed to get current weather for {location}, using fallback")
            return self._get_fallback_weather(location)
    
    def _get_fallback_weather(self, location):
        """Provide fallback weather data from cache or defaults."""
        # Check if we have cached data less than 1 hour old
        if location in self._cache:
            cache_entry = self._cache[location]
            cache_age = time.time() - cache_entry["timestamp"]
            
            # Return cached data if less than 1 hour old
            if cache_age < 3600:
                logger.info(f"Using cached weather data for {location} ({int(cache_age)}s old)")
                return {
                    **cache_entry["data"],
                    "from_cache": True,
                    "cache_age_seconds": int(cache_age)
                }
        
        # Return generic fallback if no cache or cache too old
        logger.warning(f"No valid cache for {location}, using generic fallback")
        return {
            "location": location,
            "temperature": None,
            "conditions": "Unknown",
            "is_fallback": True,
            "timestamp": int(time.time())
        }


# Updated function using the monitored client
def get_weather_data(location):
    """Get weather data for a location with monitoring and fallback."""
    client = WeatherApiClient()
    return client.get_current_weather(location)
Example: Dependency Version Pinning
When detecting loose version constraints:
// Original package.json with loose dependencies
{
  "name": "my-app",
  "version": "1.0.0",
  "dependencies": {
    "express": "^4.17.1",
    "lodash": "^4.17.15",
    "axios": "latest"
  }
}
Cursor suggestion:
// package.json with pinned dependencies
{
  "name": "my-app",
  "version": "1.0.0",
  "dependencies": {
    "express": "4.17.1",
    "lodash": "4.17.21",
    "axios": "0.21.4"
  },
  "engines": {
    "node": ">=14.0.0 <15.0.0"
  },
  "scripts": {
    "check-updates": "npx npm-check-updates --target minor",
    "update-deps": "npx npm-check-updates --target minor -u && npm install",
    "update-major": "npx npm-check-updates -u && npm install"
  }
}
Also suggest a dependency update procedure document:
# Dependency Update Procedure

## Regular Updates

We follow these guidelines for dependency updates:

1. **Weekly minor/patch updates**: Run `npm run update-deps` weekly to get non-breaking changes
2. **Monthly security review**: Review GitHub security alerts and prioritize security patches
3. **Quarterly major version evaluation**: Evaluate major version updates every quarter

## Update Process

1. Create a branch: `git checkout -b update-dependencies-YYYY-MM-DD`
2. Run the appropriate update command:
   - Minor/patch updates: `npm run update-deps`
   - Major updates: `npm run update-major`
   - Selective updates: `npm update package-name@version`
3. Run tests: `npm test`
4. Check for deprecation warnings or breaking changes
5. Update the dependency documentation if needed
6. Create a PR with a changelog of updated dependencies



---

## Adaptations and Context-Awareness

Cursor will adjust integration and dependency recommendations based on:


	1	Project Type
	--	Framework-specific integration patterns
	--	Language-appropriate dependency management
	--	Ecosystem-specific secret handling
	--	Appropriate monitoring based on project context
	2	Integration Complexity
	--	Simple patterns for straightforward integrations
	--	More robust implementations for critical dependencies
	--	Appropriate resilience based on dependency importance
	--	Caching suggestions based on data characteristics
	3	Team Size
	--	Documentation detail appropriate to team scale
	--	Governance processes matching team structure
	--	Standardization appropriate to codebase size
	--	Automation level matching team resources
	4	Project Maturity
	--	Progressive improvement recommendations
	--	Appropriate patterns for codebase age and stability
	--	Evolution of integration patterns with project growth
	--	Monitoring sophistication matching operational maturity
	5	Dependency Characteristics
	--	Different strategies for stable vs. fast-moving dependencies
	--	Versioning approaches based on package release patterns
	--	Monitoring depth based on dependency criticality
	--	Fallback complexity based on reliability history
