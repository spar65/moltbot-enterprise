# Cursor Security & Compliance Guidelines

These guidelines instruct Cursor how to assist with security and compliance aspects of software development. They define how Cursor should analyze code for vulnerabilities, suggest security improvements, and help implement compliance requirements.

---

## Security Review Assistance

### Automated Security Analysis

**Code Analysis:**
- Proactively scan code for common security vulnerabilities
- Identify OWASP Top 10 vulnerabilities in web applications
- Flag insecure coding patterns and suggest secure alternatives
- Detect hardcoded credentials and sensitive information

**Security Documentation:**
- Generate security documentation templates
- Suggest security features that should be documented
- Help document threat models for sensitive components
- Create checklists for manual security reviews

**Review Prioritization:**
- Identify high-risk areas of code requiring deeper review
- Suggest prioritization of security issues based on severity
- Flag components handling sensitive data or critical functionality
- Recommend security testing focus areas

---

## Dependency Management

### Vulnerability Detection

**Dependency Analysis:**
- Identify outdated or vulnerable dependencies
- Recognize dependency version conflicts
- Flag dependencies with known security issues
- Suggest secure alternatives for problematic libraries

**Update Recommendations:**
- Recommend specific version updates to address vulnerabilities
- Analyze potential breaking changes in dependency updates
- Suggest incremental update paths for major version changes
- Generate updated dependency configuration files

**Dependency Scanning Integration:**
- Suggest integrations with tools like Dependabot or Snyk
- Generate configuration for dependency scanning tools
- Recommend CI/CD pipeline integration for dependency checks
- Flag dependencies without vulnerability monitoring

---

## Vulnerability Remediation

### Secure Coding Suggestions

**Vulnerability Fixes:**
- Provide specific code suggestions to fix identified vulnerabilities
- Recommend proper input validation techniques
- Suggest secure authentication and authorization patterns
- Generate secure configuration for common frameworks

**Security Pattern Implementation:**
- Recommend implementation of security headers
- Suggest secure password storage and validation methods
- Provide patterns for secure API design
- Generate code for implementing proper access controls

**Framework-Specific Security:**
- Suggest framework-specific security best practices
- Identify security features available in used frameworks
- Recommend secure configuration options
- Flag disabled or misconfigured security features

---

## Compliance Support

### Regulatory Guidance

**Compliance Identification:**
- Identify potential regulatory requirements based on application type
- Suggest compliance considerations for different data types
- Flag patterns that might violate common regulations
- Recommend compliance documentation templates

**Privacy Implementation:**
- Suggest implementations for data privacy requirements
- Recommend patterns for user consent management
- Generate code for data anonymization or pseudonymization
- Identify personally identifiable information (PII) handling

**Audit Trail Implementation:**
- Recommend audit logging for sensitive operations
- Suggest non-repudiation mechanisms where required
- Generate code for secure audit trail implementation
- Flag insufficient logging of security-relevant events

---

## Authentication & Authorization

### Access Control Enhancement

**Authentication Security:**
- Identify weak authentication mechanisms
- Suggest multi-factor authentication implementation
- Recommend secure session management
- Generate code for implementing authentication security

**Authorization Patterns:**
- Suggest proper authorization checks
- Identify missing permission validations
- Recommend role-based access control implementations
- Generate code for implementing authorization patterns

**Credential Management:**
- Suggest secure credential storage
- Recommend secure password reset flows
- Identify insecure credential handling
- Generate code for implementing credential validation

---

## Data Protection

### Sensitive Data Handling

**Data Encryption:**
- Identify unencrypted sensitive data
- Suggest appropriate encryption methods
- Recommend key management practices
- Generate code for implementing encryption

**Data Validation:**
- Suggest input validation for all user-supplied data
- Recommend output encoding to prevent injection attacks
- Identify missing data sanitization
- Generate code for implementing data validation

**Data Exposure Prevention:**
- Identify potential data leakage points
- Suggest proper error handling to prevent information disclosure
- Recommend logging practices that protect sensitive data
- Flag overly verbose error messages or logs

---

## Implementation Examples

### Example: SQL Injection Prevention

```python
# Vulnerable code
def get_user(username):
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return cursor.fetchone()
```

**Cursor suggestion:**

```python
# Secure parameterized query
def get_user(username):
    """Retrieve user by username using parameterized query to prevent SQL injection."""
    query = "SELECT * FROM users WHERE username = %s"
    cursor.execute(query, (username,))
    return cursor.fetchone()
```

---

### Example: Secure Password Storage

```javascript
// Insecure password storage
function createUser(username, password) {
  const user = {
    username: username,
    password: password  // Storing plaintext password
  };
  return db.users.insert(user);
}
```

**Cursor suggestion:**

```javascript
// Secure password hashing
const bcrypt = require('bcrypt');

async function createUser(username, password) {
  const saltRounds = 12;
  const hashedPassword = await bcrypt.hash(password, saltRounds);

  const user = {
    username: username,
    password: hashedPassword
  };

  return db.users.insert(user);
}
```

---

### Example: Security Headers Implementation

```javascript
// Express app without security headers
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000);
```

**Cursor suggestion:**

```javascript
// Express app with security headers
const express = require('express');
const helmet = require('helmet');

const app = express();

app.use(helmet());

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:"],
      },
    },
    referrerPolicy: { policy: "same-origin" },
    hsts: { maxAge: 63072000, includeSubDomains: true, preload: true }
  })
);

app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(3000);
```

---

### Example: GDPR Data Subject Rights Implementation

```python
# Controller handling user data without GDPR considerations
class UserController:
    def create_user(self, user_data):
        return db.users.insert(user_data)

    def get_user(self, user_id):
        return db.users.find_by_id(user_id)
```

**Cursor suggestion:**

```python
# GDPR-compliant user controller
class UserController:
    def create_user(self, user_data, consent=None):
        if consent is None:
            consent = {}

        user_record = {
            **user_data,
            "consent": consent,
            "consent_timestamp": datetime.now().isoformat(),
            "data_collected_at": datetime.now().isoformat()
        }

        audit_logger.info("User consent recorded", extra={
            "user_id": user_record.get("id"), "consent": consent
        })

        return db.users.insert(user_record)

    def get_user(self, user_id):
        return db.users.find_by_id(user_id)

    def delete_user(self, user_id):
        user = db.users.find_by_id(user_id)
        if not user:
            return {"error": "User not found"}

        audit_logger.info("User data deleted per request", extra={"user_id": user_id})
        return db.users.delete(user_id)

    def export_user_data(self, user_id):
        user = db.users.find_by_id(user_id)
        if not user:
            return {"error": "User not found"}

        portable_data = {
            k: v for k, v in user.items() if k not in ["internal_id", "tracking_data"]
        }

        audit_logger.info("User data exported", extra={"user_id": user_id})
        return portable_data
```

---

## Adaptations and Context-Awareness

Cursor will adjust security and compliance recommendations based on:

- **Application Type:** Web, mobile, API, or desktop
- **Data Sensitivity:** PII, health, financial data
- **Framework Capabilities:** Built-in protections, plugins
- **Deployment Environment:** Cloud, on-prem, containers
- **Authentication Methods:** OAuth, sessions, API keys, tokens

More detailed info here:
- Application Type
	-- Web application-specific vulnerabilities
	-- Mobile app security considerations
	-- API security best practices
	-- Desktop application security patterns
- Data Sensitivity
	-- Higher security recommendations for financial or health data
	-- PII handling suggestions
	-- Different approaches for public vs. private data
	-- Compliance requirements based on data types
- Framework Capabilities
	-- Framework-specific security features
	-- Built-in protections in modern frameworks
	-- Security plugin recommendations
	-- Configuration options for security enhancement
- Deployment Environment
	-- Cloud-specific security recommendations
	-- On-premises deployment security
	-- Container security considerations
	-- Serverless function security patterns
- Authentication Methods
	-- Different approaches for various auth mechanisms
	-- OAuth/OIDC-specific security recommendations
	-- Session-based auth security considerations
	-- API key and token security best practices