# Cursor Coding Pattern & Guidelines

These guidelines instruct Cursor how to analyze, suggest, and generate code when operating independently from human guidance.

---

## Core Principles

### Always prefer simple solutions
- Prioritize clarity and minimal complexity in code suggestions.
- Recommend straightforward implementations over clever or complex solutions.
- When multiple implementation options exist, suggest the most readable option first.

### Avoid duplication of code
- Identify duplicated code patterns and suggest refactoring opportunities.
- Before suggesting new implementations, scan for similar functionality in the codebase.
- Recommend appropriate abstractions for repeated code (functions, classes, mixins).

### Account for different environments
- Detect environment-specific code and suggest proper configuration methods.
- Warn about hardcoded environment values and suggest environment variable usage.
- Recommend environment-specific configurations in appropriate files.

### Make only requested or clearly understood changes
- Limit code suggestions to the specific task at hand.
- Avoid suggesting unrelated changes or improvements during focused tasks.
- Flag potential scope creep in suggested implementations.

### Use existing patterns before introducing new ones
- Analyze codebase for established patterns before suggesting alternatives.
- When suggesting fixes, prioritize approaches consistent with existing code.
- If suggesting a new pattern, provide clear rationale and implementation details.

### Keep the codebase very clean and organized
- Recommend proper file organization when detecting structural issues.
- Suggest cleaning unused imports, variables, and functions.
- Enforce consistent naming conventions within language contexts.

### Avoid writing scripts in files if they're only run once
- Identify one-off script code and suggest moving to separate utility files.
- Recommend script extraction for code that isn't part of core application logic.
- Suggest appropriate locations for utility scripts within project structure.

### Avoid having files over 200–300 lines of code
- Alert when files exceed 300 lines and suggest refactoring opportunities.
- Identify logical boundaries for splitting large files.
- Provide specific suggestions for extracting components, classes, or modules.

### Mocking data is only needed for tests
- Flag mock data implementations in non-test code.
- Suggest moving mock data to appropriate test directories.
- Provide guidance on implementing proper test fixtures.

### Never add stubbing or fake data patterns to dev/prod code
- Detect stub implementations in production code and suggest alternatives.
- Recommend feature flag patterns instead of stubbed functionality.
- Suggest proper error handling instead of stub returns.

### Never overwrite the `.env` file without first asking
- Alert when operations would modify `.env` files.
- Suggest using `.env.example` for demonstrating required variables.
- Recommend proper environment variable management patterns.

---

## AI-Assisted Coding Guidelines

### 1. Code Style & Consistency

**Style Enforcement:**
- Suggest fixes for style violations using detected standards.
- Enforce PEP 8 for Python, ESLint for JavaScript, etc.
- Default to community standards if no rules are detected.

**Naming Suggestions:**
- Recommend descriptive, consistent names (variables, functions, classes).
- Match naming style to project conventions.
- Flag inconsistent patterns.

**Formatting Assistance:**
- Suggest proper indentation, spacing, and bracket usage.
- Fix inconsistent formatting.
- Recommend line breaks for readability.

**Linting Integration:**
- Parse `.editorconfig`, `.eslintrc`, `pyproject.toml`, etc.
- Respect project-specific linting rules.

---

### 2. Documentation Generation

**Docstring Assistance:**
- Suggest docstrings for functions and classes using appropriate format.
- Include parameters, returns, and summaries.

**Comment Suggestions:**
- Recommend comments for complex logic or edge cases.
- Focus on “why” instead of “what”.

**README Generation:**
- Generate README templates with structure, setup, and usage.
- Include CLI or API documentation when appropriate.

**API Documentation:**
- Detect endpoints, recommend OpenAPI/Swagger.
- Generate sample requests/responses.

---

### 3. Testing Suggestions

**Test Coverage:**
- Suggest tests for new code and untested paths.
- Generate test templates.

**Framework Detection:**
- Use appropriate frameworks (pytest, Jest, etc.).

**Test Organization:**
- Suggest correct file locations and naming.
- Mirror implementation structure.

**Mock Generation:**
- Generate mocks for dependencies.
- Keep mocks in test files.

---

### 4. Error Handling & Logging

**Error Detection:**
- Flag inadequate error handling.
- Recommend specific exception types.

**Logging Recommendations:**
- Suggest consistent log patterns.
- Use appropriate log levels.

**Fallback Suggestions:**
- Recommend graceful failures and default values.

---

### 5. Performance Optimization

**Complexity Analysis:**
- Flag inefficient patterns.
- Suggest better algorithms.

**Optimization Suggestions:**
- Recommend caching, query optimization.
- Identify performance bottlenecks.

**Premature Optimization Warning:**
- Warn against optimizing without profiling.
- Prioritize readability.

---

### 6. Security Enhancement

**Vulnerability Detection:**
- Flag security issues like SQL injection or XSS.

**Secrets Management:**
- Detect hardcoded secrets, suggest env vars.
- Avoid logging sensitive data.

**Input Validation:**
- Recommend sanitization and validation.

---

### 7. Context-Aware Assistance

**Project Pattern Learning:**
- Learn from codebase patterns and style.

**Adaptive Suggestions:**
- Tailor recommendations to complexity and skill level.

**Framework-Specific Knowledge:**
- Suggest best practices for detected frameworks.

**Learning Mode:**
- Adapt suggestions based on feedback.

---

### 8. Refactoring Intelligence

**Technical Debt Identification:**
- Flag code smells, suggest refactoring.

**Incremental Improvement:**
- Recommend small improvements that preserve behavior.

**Comprehensive Refactoring:**
- Offer large-scale changes with plans and examples.

---

### 9. Implementation Guidance

**Solution Discovery:**
- Scan for similar implementations.

**Code Generation:**
- Provide full code, handle edge cases.

**Interactive Refinement:**
- Ask for clarification, iterate as needed.

---

### 10. Automation Rules

**Automatic Enforcement:**
- Enforce file size, function size, style, and secret rules.

**Warning Thresholds:**
- Warn for near-limit files and complexity issues.

**Suggestion Levels:**
- Categorize as:
  - **Critical:** Security, errors
  - **Recommended:** Style, optimizations
  - **Optional:** Alternatives

---

## Implementation Examples

### Identifying Duplicated Code

# Original code with duplication
def process_user_data(user_data):
    # Extract user information
    name = user_data.get('name', 'Unknown')
    email = user_data.get('email', 'no-email@example.com')
    
    # Validate email format
    if '@' not in email or '.' not in email:
        return {"error": "Invalid email format"}
    
    # Process user data
    return {"status": "success", "user": {"name": name, "email": email}}

def process_admin_data(admin_data):
    # Extract admin information
    name = admin_data.get('name', 'Unknown')
    email = admin_data.get('email', 'no-email@example.com')
    
    # Validate email format
    if '@' not in email or '.' not in email:
        return {"error": "Invalid email format"}
    
    # Process admin data
    return {"status": "success", "admin": {"name": name, "email": email}}
Cursor suggestion:
# Extract common validation function
def validate_email(email):
    """Validate email format.
    
    Args:
        email: Email string to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    return '@' in email and '.' in email

def process_user_data(user_data):
    # Extract user information
    name = user_data.get('name', 'Unknown')
    email = user_data.get('email', 'no-email@example.com')
    
    # Validate email format
    if not validate_email(email):
        return {"error": "Invalid email format"}
    
    # Process user data
    return {"status": "success", "user": {"name": name, "email": email}}

def process_admin_data(admin_data):
    # Extract admin information
    name = admin_data.get('name', 'Unknown')
    email = admin_data.get('email', 'no-email@example.com')
    
    # Validate email format
    if not validate_email(email):
        return {"error": "Invalid email format"}
    
    # Process admin data
    return {"status": "success", "admin": {"name": name, "email": email}}

Example: Refactoring Large Files
When a file exceeds 300 lines, Cursor will suggest splitting it based on logical boundaries:
Cursor suggestion:
This file has grown to 347 lines and should be refactored into smaller modules.
Suggested split:

1. Move UserAuthentication class (lines 120-210) to auth/user_authentication.py
2. Move AdminAuthentication class (lines 211-290) to auth/admin_authentication.py
3. Keep base Authentication class in the current file
4. Update imports in affected files

Example: Security Enhancement
// Original code with security issue
app.get('/api/user/:id', (req, res) => {
  const userId = req.params.id;
  const query = `SELECT * FROM users WHERE id = ${userId}`;
  
  db.query(query, (err, result) => {
    if (err) {
      res.status(500).send("Error retrieving user");
    } else {
      res.json(result);
    }
  });
});
Cursor suggestion:
// Security issue detected: SQL injection vulnerability
// Using parameterized queries instead
app.get('/api/user/:id', (req, res) => {
  const userId = req.params.id;
  const query = "SELECT * FROM users WHERE id = ?";
  
  db.query(query, [userId], (err, result) => {
    if (err) {
      res.status(500).send("Error retrieving user");
    } else {
      res.json(result);
    }
  });
});


Final Notes
Cursor will adapt these guidelines based on project context and user preferences. The AI will learn from the codebase to better align with established patterns and conventions. When multiple valid approaches exist, Cursor will suggest the option that best balances maintainability, performance, and consistency with the existing code.
