# Cursor Deployment & Infrastructure Guidelines

These guidelines instruct Cursor how to assist with deployment, infrastructure, and operational aspects of software development. They define how Cursor should analyze, suggest improvements, and generate configuration for deployment pipelines and infrastructure.

## Deployment Strategy Assistance

### Pipeline Detection & Recommendations

**CI/CD Configuration Analysis:**
- Identify existing CI/CD configurations (GitHub Actions, Jenkins, GitLab CI, etc.)
- Suggest improvements to build, test, and deployment workflows
- Flag missing steps in deployment pipelines (security scanning, test coverage, etc.)
- Generate configuration templates for missing pipeline components

**Containerization Support:**
- Detect containerization needs based on project structure
- Suggest Dockerfile optimizations when reviewing existing configurations
- Generate efficient Dockerfiles with appropriate base images and multi-stage builds
- Provide docker-compose configurations for local development environments

**Deployment Procedure Assistance:**
- Recommend clear procedures for code promotion between environments
- Suggest environment-specific configuration management approaches
- Identify hardcoded environment values and suggest externalization
- Generate deployment documentation templates

---

## Rollback Mechanism Support

### Rollback Strategy Suggestions

**Rollback Plan Generation:**
- Suggest appropriate rollback strategies based on deployment methods
- Generate rollback scripts or commands for different deployment scenarios
- Flag deployments that lack clear rollback mechanisms
- Recommend database migration rollback procedures

**Deployment Safety Enhancements:**
- Suggest feature flag implementations for risky changes
- Recommend canary deployment approaches for critical updates
- Identify potential points of failure in deployment processes
- Suggest blue/green deployment configurations when appropriate

**Testing Rollback Procedures:**
- Recommend automated testing of rollback procedures
- Suggest verification steps post-rollback
- Flag untested rollback mechanisms
- Generate test scripts for validating rollback processes

---

## Monitoring Implementation

### Monitoring Configuration Assistance

**Monitoring Setup:**
- Identify appropriate monitoring tools based on project technology stack
- Generate monitoring configuration files (Prometheus, Datadog, etc.)
- Suggest health check endpoints for services
- Recommend application-specific metrics to track

**Alert Configuration:**
- Suggest alert thresholds for key service metrics
- Generate alerting rules for critical conditions
- Recommend appropriate alert routing and escalation
- Flag missing alerts for critical functionality

**Dashboard Creation:**
- Generate dashboard configurations for visualization tools
- Suggest key metrics to display on operational dashboards
- Recommend visualization approaches for different metric types
- Provide templates for status pages and user-facing monitoring

---

## Logging Enhancement

### Logging Implementation

**Logging Structure:**
- Identify inconsistent logging patterns
- Suggest structured logging implementations
- Generate log configuration for centralized solutions (ELK stack, etc.)
- Recommend standardized log levels and their appropriate usage

**Log Content Optimization:**
- Flag sensitive data in log messages
- Suggest contextual information to include in logs
- Recommend correlation IDs for request tracing
- Identify insufficient error logging

**Log Management:**
- Suggest log rotation and retention policies
- Recommend archival strategies for historical logs
- Generate log aggregation configurations
- Suggest log analysis approaches for identifying patterns

---

## Performance Metrics & Optimization

### Performance Monitoring & Analysis

**Key Metric Identification:**
- Suggest critical performance indicators for different service types
- Generate monitoring configurations for performance metrics
- Recommend baseline thresholds for performance alerts
- Identify missing performance measurements

**Performance Optimization:**
- Flag potential performance bottlenecks in code
- Suggest caching strategies where appropriate
- Recommend database query optimizations
- Identify resource-intensive operations that could be optimized

**Scaling Guidance:**
- Suggest auto-scaling configurations based on load patterns
- Recommend horizontal vs. vertical scaling approaches
- Generate infrastructure-as-code for scalable architectures
- Identify components that may become scaling bottlenecks

---

## Infrastructure-as-Code Support

### IaC Implementation

**Code Generation:**
- Provide Terraform, CloudFormation, or other IaC templates
- Suggest best practices for infrastructure versioning
- Generate modular, reusable infrastructure components
- Flag hardcoded values in infrastructure definitions

**Security Best Practices:**
- Identify insecure infrastructure configurations
- Suggest security group and network access limitations
- Recommend encryption for data at rest and in transit
- Flag excessive permissions in service roles

**Environment Consistency:**
- Suggest approaches for maintaining parity between environments
- Identify environment-specific configurations that should be parameterized
- Generate environment configuration files with appropriate defaults
- Recommend strategies for environment secret management

---

## Disaster Recovery Planning

### DR Strategy

**Backup Configuration:**
- Suggest backup strategies for different data types
- Generate backup configuration scripts
- Recommend backup frequency and retention policies
- Flag critical data without backup procedures

**Recovery Procedure Assistance:**
- Generate disaster recovery runbooks
- Suggest recovery time objective (RTO) targets
- Recommend recovery testing procedures
- Identify single points of failure in architecture

**Resilience Enhancement:**
- Suggest multi-region deployment configurations
- Recommend redundancy for critical components
- Generate chaos engineering test scenarios
- Flag availability concerns in architecture

---

## Implementation Examples

### Example: Dockerfile Optimization

```dockerfile
# Original Dockerfile
FROM ubuntu:latest
RUN apt-get update
RUN apt-get install -y python3 python3-pip
COPY . /app
WORKDIR /app
RUN pip3 install -r requirements.txt
CMD ["python3", "app.py"]
```

**Cursor suggestion:**

```dockerfile
# Optimized Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Copy and install dependencies first (better layer caching)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Run as non-root user for security
RUN useradd -m appuser
USER appuser

# Health check for container orchestration
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:8000/health || exit 1

CMD ["python", "app.py"]
```

---

### Example: CI/CD Pipeline Enhancement

```yaml
# Original workflow
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build
        run: docker build -t myapp .
      - name: Deploy
        run: ./deploy.sh
```

**Cursor suggestion:**

```yaml
# Enhanced workflow with testing, security scanning, and rollback
name: Build, Test, and Deploy

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run tests
        run: pytest
      - name: Check test coverage
        run: pytest --cov=app --cov-fail-under=80

  security-scan:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run dependency security scan
        uses: snyk/actions/python@master
      - name: Run code security scan
        uses: github/codeql-action/analyze@v1

  deploy:
    needs: [test, security-scan]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build
        run: docker build -t myapp:${{ github.sha }} .
      - name: Tag stable
        run: docker tag myapp:${{ github.sha }} myapp:stable
      - name: Deploy
        run: ./deploy.sh
      - name: Verify deployment
        run: ./verify_deployment.sh
      - name: Rollback on failure
        if: failure()
        run: ./rollback.sh
```

---

### Example: Logging Configuration

```python
# Original code with inconsistent logging
import logging

def process_payment(payment_data):
    # Some developers use print
    print(f"Processing payment for {payment_data['amount']}")
    
    try:
        # Some use logging but inconsistently
        result = payment_service.charge(payment_data)
        logging.info("Payment processed")
        return result
    except Exception as e:
        print(f"Error in payment: {str(e)}")
        return None
```

**Cursor suggestion:**

```python
# Standardized structured logging
import logging
import json

logger = logging.getLogger(__name__)

def process_payment(payment_data, request_id=None):
    logger.info("Processing payment", extra={
        "request_id": request_id,
        "amount": payment_data["amount"],
        "currency": payment_data["currency"],
        "payment_method": payment_data["method"]
    })
    
    try:
        result = payment_service.charge(payment_data)
        logger.info("Payment processed successfully", extra={
            "request_id": request_id,
            "transaction_id": result["transaction_id"],
            "status": result["status"]
        })
        return result
    except Exception as e:
        logger.error("Payment processing failed", extra={
            "request_id": request_id,
            "error": str(e),
            "payment_method": payment_data["method"]
        })
        return None
```

---

### Example: Monitoring Configuration

```python
# Prometheus monitoring configuration for a Flask application

from prometheus_client import Counter, Histogram
from prometheus_flask_exporter import PrometheusMetrics

metrics = PrometheusMetrics(app)

REQUEST_COUNT = Counter(
    'request_count', 'App Request Count',
    ['app_name', 'method', 'endpoint', 'http_status']
)
REQUEST_LATENCY = Histogram(
    'request_latency_seconds', 'Request latency',
    ['app_name', 'endpoint']
)

@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    REQUEST_COUNT.labels(
        'my_app', 
        request.method, 
        request.path, 
        response.status_code
    ).inc()
    
    request_latency = time.time() - request.start_time
    REQUEST_LATENCY.labels('my_app', request.path).observe(request_latency)
    
    return response

@app.route('/health')
@metrics.do_not_track()
def health():
    return {"status": "healthy"}
```

---

## Adaptations and Context-Awareness

Cursor will adjust deployment and infrastructure recommendations based on:

- **Project Scale**
	-- Simpler configurations for small projects
	-- More comprehensive setups for enterprise applications
- **Technology Stack**
	-- Framework-specific deployment strategies
	-- Language-appropriate monitoring and logging approaches
- **Observed Infrastructure**
	-- Adaptation to detected cloud providers or hosting environments
	-- Respect for existing architectural decisions
- **Deployment Frequency**
	-- Optimize for observed deployment patterns
	-- Suggest appropriate automation based on release cadence
- **Application Type**
	-- Different approaches for APIs, web applications, data processing services
	-- Specialized monitoring for different service types
