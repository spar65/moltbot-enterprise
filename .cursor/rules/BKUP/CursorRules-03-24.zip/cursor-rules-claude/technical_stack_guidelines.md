
Cursor Technical Stack Guidelines
These guidelines instruct Cursor how to provide code suggestions, completions, and recommendations based on our project's defined technical stack. Cursor should follow these rules when analyzing code, suggesting improvements, and generating new code.
1. Backend (Python)
Language & Framework Detection
	•	Python Recognition:
	◦	Identify Python files and suggest Python-specific improvements
	◦	Recommend Python 3.9+ features and syntax
	◦	Flag deprecated or outdated Python language patterns
	◦	Generate PEP 8 compliant code
	•	Framework Standardization:
	◦	Detect FastAPI as preferred backend framework
	◦	Suggest FastAPI-specific patterns and best practices
	◦	Recommend appropriate FastAPI extensions and plugins
	◦	Alert if other frameworks (Django, Flask) are used
	•	Dependency Management:
	◦	Recommend Poetry for dependency management
	◦	Suggest proper Poetry configuration patterns
	◦	Generate appropriate pyproject.toml entries
	◦	Alert when encountering alternative dependency management tools

2. Frontend (HTML/JS)
Frontend Technology Patterns
	•	Framework Recognition:
	◦	Identify React as our JavaScript framework
	◦	Suggest React component patterns and best practices
	◦	Recommend React hooks over class components
	◦	Alert if other frameworks (Vue, Angular) are detected
	•	Build System Integration:
	◦	Recommend Webpack configurations
	◦	Suggest performance optimizations for builds
	◦	Generate appropriate webpack config entries
	◦	Recommend appropriate loaders and plugins
	•	Styling Approach:
	◦	Identify Tailwind CSS as our styling approach
	◦	Suggest appropriate Tailwind utility classes
	◦	Recommend Tailwind configuration best practices
	◦	Generate component styling using Tailwind patterns

3. Databases (SQL)
Database Implementation Guidelines
	•	PostgreSQL Focus:
	◦	Recognize PostgreSQL as preferred database
	◦	Suggest PostgreSQL-specific features and patterns
	◦	Recommend appropriate PostgreSQL configuration
	◦	Alert if other databases are referenced
	•	ORM Recognition:
	◦	Identify SQLAlchemy as our ORM
	◦	Suggest SQLAlchemy model patterns
	◦	Recommend query optimization techniques
	◦	Generate SQLAlchemy models and queries
	•	Migration Management:
	◦	Recognize Alembic as our migration tool
	◦	Suggest proper migration patterns
	◦	Recommend migration testing approaches
	◦	Generate Alembic migration templates

4. Search (Elasticsearch)
Elasticsearch Integration
	•	Client Detection:
	◦	Identify elasticsearch-py as our client library
	◦	Suggest proper Elasticsearch client configuration
	◦	Recommend connection pooling and retry patterns
	◦	Generate Elasticsearch client setup code
	•	Query Construction:
	◦	Recommend proper Elasticsearch DSL patterns
	◦	Suggest query optimization techniques
	◦	Generate efficient search queries
	◦	Alert on potentially inefficient query patterns
	•	Index Management:
	◦	Suggest proper index naming conventions
	◦	Recommend index configuration best practices
	◦	Generate index creation code with appropriate mappings
	◦	Suggest separate dev/prod index patterns

5. Testing (Python Tests)
Testing Framework Implementation
	•	Pytest Recognition:
	◦	Identify pytest as our testing framework
	◦	Suggest pytest fixtures and patterns
	◦	Recommend test organization approaches
	◦	Generate pytest test templates
	•	Test Coverage Enhancement:
	◦	Recommend test coverage improvements
	◦	Suggest untested code paths
	◦	Generate tests for critical functionality
	◦	Recommend property-based testing where appropriate
	•	Mock Implementation:
	◦	Suggest pytest-mock patterns
	◦	Recommend appropriate mocking strategies
	◦	Generate mock implementations for external dependencies
	◦	Alert on test isolation issues

6. Deployment & Environment Management
Containerization Support
	•	Docker Recognition:
	◦	Identify Docker as our containerization solution
	◦	Suggest Dockerfile optimizations
	◦	Recommend multi-stage build patterns
	◦	Generate efficient Docker configurations
	•	Environment Configuration:
	◦	Recognize environment variable patterns
	◦	Suggest secure environment configuration
	◦	Recommend configuration management approaches
	◦	Generate environment configuration templates
	•	CI/CD Integration:
	◦	Identify GitHub Actions as our CI/CD system
	◦	Suggest workflow optimizations
	◦	Recommend testing and deployment pipeline improvements
	◦	Generate GitHub Actions workflow configurations

Implementation Examples
Example: FastAPI Endpoint Generation
When detecting the need for a new API endpoint:
# Cursor suggestion for a new FastAPI endpoint
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional

from app.dependencies import get_db
from app.models.user import User
from app.schemas.user import UserCreate, UserResponse

router = APIRouter(prefix="/users", tags=["users"])

@router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    """
    Create a new user.
    
    Returns:
        The created user
    """
    # Check if user with this email already exists
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    db_user = User(
        email=user.email,
        hashed_password=hash_password(user.password),
        full_name=user.full_name
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return db_user

@router.get("/", response_model=List[UserResponse])
def get_users(
    skip: int = 0, 
    limit: int = 100, 
    db: Session = Depends(get_db)
):
    """
    Get all users with pagination.
    
    Args:
        skip: Number of users to skip
        limit: Maximum number of users to return
        
    Returns:
        List of users
    """
    users = db.query(User).offset(skip).limit(limit).all()
    return users

@router.get("/{user_id}", response_model=UserResponse)
def get_user(user_id: int, db: Session = Depends(get_db)):
    """
    Get a specific user by ID.
    
    Args:
        user_id: The ID of the user to retrieve
        
    Returns:
        The requested user
        
    Raises:
        HTTPException: If user not found
    """
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    return user
Example: React Component with Tailwind
When generating a new React component:
// Cursor suggestion for a React component with Tailwind CSS
import React, { useState, useEffect } from 'react';
import { useQuery } from 'react-query';
import { Spinner, Alert } from '../components/ui';

/**
 * User list component that fetches and displays users
 */
const UserList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const { 
    data: users,
    isLoading,
    isError,
    error
  } = useQuery(['users', searchTerm], () => 
    fetch(`/api/users?search=${searchTerm}`).then(res => res.json())
  );
  
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" />
      </div>
    );
  }
  
  if (isError) {
    return (
      <Alert type="error">
        Error loading users: {error.message}
      </Alert>
    );
  }
  
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-800">Users</h2>
        <input
          type="text"
          placeholder="Search users..."
          value={searchTerm}
          onChange={handleSearch}
          className="px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      
      {users.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No users found</p>
      ) : (
        <div className="bg-white shadow overflow-hidden rounded-md">
          <ul className="divide-y divide-gray-200">
            {users.map(user => (
              <li key={user.id} className="px-6 py-4 hover:bg-gray-50">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                      <span className="text-blue-800 font-medium">
                        {user.full_name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  </div>
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">{user.full_name}</h3>
                    <p className="text-gray-500">{user.email}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default UserList;
Example: SQLAlchemy Model with Alembic Migration
When suggesting a new database model:
# Cursor suggestion for SQLAlchemy model
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    posts = relationship("Post", back_populates="author")
    
    def __repr__(self):
        return f"User(id={self.id}, email={self.email}, full_name={self.full_name})"
Also suggest an Alembic migration:
"""create users table

Revision ID: a1b2c3d4e5f6
Revises: 
Create Date: 2023-01-01 12:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'a1b2c3d4e5f6'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'users',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('email', sa.String(), nullable=False),
        sa.Column('hashed_password', sa.String(), nullable=False),
        sa.Column('full_name', sa.String(), nullable=True),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('is_superuser', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_users_email'), 'users', ['email'], unique=True)
    op.create_index(op.f('ix_users_id'), 'users', ['id'], unique=False)


def downgrade():
    op.drop_index(op.f('ix_users_id'), table_name='users')
    op.drop_index(op.f('ix_users_email'), table_name='users')
    op.drop_table('users')
Example: Elasticsearch Query Generation
When suggesting Elasticsearch query implementation:
# Cursor suggestion for Elasticsearch integration
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from typing import List, Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class ElasticsearchClient:
    """Client for interacting with Elasticsearch."""
    
    def __init__(self, hosts: List[str], index_prefix: str = ""):
        """
        Initialize Elasticsearch client.
        
        Args:
            hosts: List of Elasticsearch hosts
            index_prefix: Optional prefix for all indices (e.g., "dev-" or "prod-")
        """
        self.client = Elasticsearch(hosts)
        self.index_prefix = index_prefix
    
    def get_index_name(self, base_name: str) -> str:
        """Get full index name with prefix."""
        return f"{self.index_prefix}{base_name}"
    
    def create_index(self, base_name: str, mappings: Dict[str, Any]) -> bool:
        """
        Create an Elasticsearch index with specified mappings.
        
        Args:
            base_name: Base index name (without prefix)
            mappings: Elasticsearch mappings configuration
            
        Returns:
            bool: True if created successfully
        """
        index_name = self.get_index_name(base_name)
        
        try:
            response = self.client.indices.create(
                index=index_name,
                body={
                    "settings": {
                        "number_of_shards": 3,
                        "number_of_replicas": 1,
                        "analysis": {
                            "analyzer": {
                                "custom_analyzer": {
                                    "type": "custom",
                                    "tokenizer": "standard",
                                    "filter": ["lowercase", "asciifolding"]
                                }
                            }
                        }
                    },
                    "mappings": mappings
                }
            )
            logger.info(f"Created index {index_name}: {response}")
            return True
        except Exception as e:
            logger.error(f"Error creating index {index_name}: {str(e)}")
            return False
    
    def index_document(self, base_name: str, document: Dict[str, Any], doc_id: Optional[str] = None) -> bool:
        """
        Index a single document.
        
        Args:
            base_name: Base index name (without prefix)
            document: Document to index
            doc_id: Optional document ID
            
        Returns:
            bool: True if indexed successfully
        """
        index_name = self.get_index_name(base_name)
        
        try:
            response = self.client.index(
                index=index_name,
                id=doc_id,
                body=document
            )
            logger.debug(f"Indexed document in {index_name}: {response}")
            return True
        except Exception as e:
            logger.error(f"Error indexing document in {index_name}: {str(e)}")
            return False
    
    def bulk_index(self, base_name: str, documents: List[Dict[str, Any]]) -> int:
        """
        Bulk index multiple documents.
        
        Args:
            base_name: Base index name (without prefix)
            documents: List of documents to index
            
        Returns:
            int: Number of documents successfully indexed
        """
        index_name = self.get_index_name(base_name)
        
        actions = [
            {
                "_index": index_name,
                "_id": doc.get("id"),
                "_source": doc
            }
            for doc in documents
        ]
        
        try:
            success, errors = bulk(self.client, actions, refresh=True)
            if errors:
                logger.warning(f"Errors during bulk indexing: {errors}")
            return success
        except Exception as e:
            logger.error(f"Error bulk indexing documents in {index_name}: {str(e)}")
            return 0
    
    def search(self, base_name: str, query: Dict[str, Any], size: int = 10, from_: int = 0) -> Dict[str, Any]:
        """
        Search documents in an index.
        
        Args:
            base_name: Base index name (without prefix)
            query: Elasticsearch query
            size: Number of results to return
            from_: Starting point for pagination
            
        Returns:
            Dict containing search results
        """
        index_name = self.get_index_name(base_name)
        
        try:
            response = self.client.search(
                index=index_name,
                body=query,
                size=size,
                from_=from_
            )
            return response
        except Exception as e:
            logger.error(f"Error searching in {index_name}: {str(e)}")
            return {"error": str(e)}

# Example usage for users
def search_users(es_client: ElasticsearchClient, query_string: str, page: int = 1, size: int = 10) -> Dict[str, Any]:
    """
    Search for users by name or email.
    
    Args:
        es_client: Elasticsearch client
        query_string: Query string to search for
        page: Page number (1-based)
        size: Number of results per page
        
    Returns:
        Dict containing search results
    """
    from_ = (page - 1) * size
    
    query = {
        "query": {
            "multi_match": {
                "query": query_string,
                "fields": ["full_name^2", "email"],
                "type": "best_fields",
                "fuzziness": "AUTO"
            }
        },
        "highlight": {
            "fields": {
                "full_name": {},
                "email": {}
            }
        },
        "_source": ["id", "full_name", "email", "created_at"]
    }
    
    return es_client.search("users", query, size=size, from_=from_)
Example: Pytest Test Implementation
When suggesting tests for a component:
# Cursor suggestion for pytest tests
import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.main import app
from app.models.user import User
from app.tests.utils.user import create_test_user
from app.tests.utils.utils import random_email, random_lower_string

client = TestClient(app)

def test_create_user(db: Session):
    """Test creating a new user."""
    email = random_email()
    password = random_lower_string()
    full_name = random_lower_string()
    
    data = {
        "email": email,
        "password": password,
        "full_name": full_name
    }
    
    response = client.post("/users/", json=data)
    assert response.status_code == 201
    
    # Check response contains expected data
    content = response.json()
    assert content["email"] == email
    assert content["full_name"] == full_name
    assert "id" in content
    assert "password" not in content
    
    # Verify user was created in the database
    db_user = db.query(User).filter(User.email == email).first()
    assert db_user is not None
    assert db_user.email == email
    assert db_user.full_name == full_name

def test_create_user_duplicate_email(db: Session):
    """Test creating a user with an email that already exists."""
    # Create a user first
    existing_user = create_test_user(db)
    
    # Try to create another user with the same email
    data = {
        "email": existing_user.email,
        "password": random_lower_string(),
        "full_name": random_lower_string()
    }
    
    response = client.post("/users/", json=data)
    assert response.status_code == 400
    content = response.json()
    assert "Email already registered" in content["detail"]
    
def test_get_users(db: Session):
    """Test retrieving a list of users."""
    # Create test users
    for _ in range(3):
        create_test_user(db)
    
    response = client.get("/users/")
    assert response.status_code == 200
    
    content = response.json()
    assert len(content) >= 3
    
    # Verify response structure
    for user in content:
        assert "id" in user
        assert "email" in user
        assert "full_name" in user
        assert "password" not in user

def test_get_user(db: Session):
    """Test retrieving a specific user by ID."""
    test_user = create_test_user(db)
    
    response = client.get(f"/users/{test_user.id}")
    assert response.status_code == 200
    
    content = response.json()
    assert content["id"] == test_user.id
    assert content["email"] == test_user.email
    assert content["full_name"] == test_user.full_name
    assert "password" not in content
    
def test_get_user_not_found():
    """Test retrieving a user that doesn't exist."""
    response = client.get("/users/999999")
    assert response.status_code == 404
    content = response.json()
    assert "User not found" in content["detail"]

@pytest.fixture
def db():
    """Database session fixture."""
    from app.database import get_db, Base, engine
    
    # Create the tables
    Base.metadata.create_all(bind=engine)
    
    # Get a database session
    db = next(get_db())
    
    yield db
    
    # Clean up
    db.close()
Example: Docker Configuration
When suggesting Docker setup:
# Cursor suggestion for a Dockerfile
# Multi-stage build for Python FastAPI application

# Stage 1: Build dependencies
FROM python:3.9-slim as builder

WORKDIR /app

# Install Poetry and configure it to not create a virtual environment
RUN pip install poetry && \
    poetry config virtualenvs.create false

# Copy only the files needed for installing dependencies
COPY pyproject.toml poetry.lock* ./

# Install production dependencies
RUN poetry install --no-dev

# Stage 2: Runtime
FROM python:3.9-slim

WORKDIR /app

# Set environment variables
ENV PYTHONDONTWRITEBYTECODE=1 \
    PYTHONUNBUFFERED=1 \
    ENVIRONMENT=production

# Copy dependencies from builder stage
COPY --from=builder /usr/local/lib/python3.9/site-packages /usr/local/lib/python3.9/site-packages
COPY --from=builder /usr/local/bin /usr/local/bin

# Copy application code
COPY ./app ./app

# Create non-root user
RUN adduser --disabled-password --gecos "" appuser && \
    chown -R appuser:appuser /app

USER appuser

# Expose application port
EXPOSE 8000

# Run the application with proper settings for production
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
Also suggest a docker-compose.yml file:
# Cursor suggestion for docker-compose.yml
version: '3.8'

services:
  api:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/app
      - SECRET_KEY=${SECRET_KEY}
      - ELASTICSEARCH_HOSTS=http://elasticsearch:9200
    depends_on:
      - db
      - elasticsearch
    volumes:
      - ./app:/app/app
    restart: always

  db:
    image: postgres:13
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=app
    ports:
      - "5432:5432"

  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:7.14.0
    environment:
      - discovery.type=single-node
      - "ES_JAVA_OPTS=-Xms512m -Xmx512m"
    volumes:
      - elasticsearch_data:/usr/share/elasticsearch/data
    ports:
      - "9200:9200"

volumes:
  postgres_data:
  elasticsearch_data:

Adaptations and Context-Awareness
Cursor will adjust technical recommendations based on:
	1	Project Size
	--	Simpler implementations for small projects
	--	More comprehensive solutions for larger applications
	--	Appropriate complexity based on codebase size
	2	Project Phase
	--	MVP-focused approaches for early-stage projects
	--	More robust implementations for mature applications
	--	Gradual sophistication recommendations
	3	File Context
	--	Adaptation based on surrounding code patterns
	--	Consistency with established project conventions
	--	Appropriate recommendations for file purpose
	4	Technical Requirements
	--	Performance-focused suggestions for critical paths
	--	Maintainability-focused patterns for complex logic
	--	Security-focused approaches for sensitive operations
	5	Team Expertise
	--	Accessible patterns for junior-friendly codebases
	--	Advanced techniques for experienced teams
	--	Clear documentation for complex implementations
