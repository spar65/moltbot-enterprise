
# Cursor Operations & Incident Management Guidelines

These guidelines instruct Cursor how to assist with operational procedures and incident management. They define how Cursor should analyze operational code, suggest monitoring improvements, and assist with incident management automation.

---

## Alerting Implementation

### Alert Configuration Assistance

**Alert System Detection:**
- Identify monitoring systems in use (Prometheus, Datadog, New Relic, etc.)
- Suggest appropriate alerting configurations for detected technologies
- Recommend alert standardization across related components
- Flag missing alerts for critical functionality

**Alert Definition Generation:**
- Generate alert rule configurations for common failure scenarios
- Suggest appropriate thresholds based on observed patterns
- Recommend alert routing and severity classifications
- Generate alert documentation templates

**Noise Reduction Strategies:**
- Identify potential alert storms and suggest aggregation
- Recommend correlation rules for related alerts
- Suggest alert debouncing and cooldown periods
- Identify redundant or overlapping alerts

---

## Incident Response Automation

### Response Procedure Development

**Response Plan Generation:**
- Create incident response procedure templates
- Generate runbooks for common failure scenarios
- Suggest roles and responsibilities for incident management
- Provide checklists for incident response steps

**Automation Implementation:**
- Identify manual steps that could be automated
- Generate scripts for common remediation actions
- Suggest integration points for automated response
- Recommend tooling for incident management

**Severity Classification:**
- Suggest incident severity definitions
- Recommend appropriate response times for different severities
- Generate incident classification documentation
- Identify escalation criteria and procedures

---

## Post-Incident Analysis

### Root Cause Analysis Support

**Analysis Structure:**
- Generate post-mortem templates with standard sections
- Suggest data gathering procedures for incident analysis
- Recommend timeline reconstruction techniques
- Provide frameworks for systematic root cause analysis

**Corrective Action Tracking:**
- Suggest tracking mechanisms for corrective actions
- Generate implementation plans for identified improvements
- Recommend verification procedures for fixes
- Flag similar past incidents when relevant

**Knowledge Capture:**
- Suggest incident knowledge base structure
- Generate lesson-learned documentation
- Recommend information sharing procedures
- Identify patterns across multiple incidents

---

## Operational Communication

### Communication Assistance

**Channel Recommendation:**
- Suggest appropriate communication tools for incidents
- Recommend establishing dedicated incident channels
- Generate communication procedures for different severity levels
- Identify stakeholders for different incident types

**Status Update Templates:**
- Create templates for incident updates
- Generate external communication examples
- Suggest status page integration
- Recommend communication frequency based on severity

**User Impact Communication:**
- Generate templates for user-facing incident communications
- Suggest appropriate detail level for external updates
- Recommend notification mechanisms based on impact
- Provide resolution announcement templates

---

## Resilience Improvement

### Continuous Enhancement

**Resilience Analysis:**
- Identify single points of failure in architecture
- Suggest redundancy improvements
- Recommend chaos engineering approaches
- Generate reliability enhancement proposals

**Operational Metrics:**
- Suggest key operational metrics to track
- Generate monitoring configurations for reliability metrics
- Recommend SLO/SLI definitions
- Identify missing health checks

**Documentation Enhancement:**
- Identify outdated or insufficient operational documentation
- Generate improved runbooks and procedures
- Suggest documentation testing through simulations
- Recommend knowledge sharing mechanisms

---

## On-Call Support

### On-Call Experience Enhancement

**Runbook Generation:**
- Create comprehensive runbooks for common issues
- Generate troubleshooting decision trees
- Suggest diagnostic command sequences
- Provide resolution procedures with verification steps

**Alert Context Enhancement:**
- Recommend additional context to include in alerts
- Suggest linking alerts to specific runbooks
- Generate alert annotation templates
- Recommend alert grouping for related issues

**Shift Handover Assistance:**
- Generate on-call handover templates
- Suggest knowledge transfer procedures
- Recommend incident status tracking mechanisms
- Provide ongoing incident documentation templates

---

## Implementation Examples

### Example: Alert Configuration

```python
# Application code without health checks or alerting
def process_payment(payment_data):
    try:
        result = payment_service.charge(payment_data)
        return result
    except Exception as e:
        logger.error(f"Payment failed: {str(e)}")
        return None
```

**Cursor suggestion:**

```python
# Implementing health checks and alert instrumentation
from prometheus_client import Counter, Summary, Gauge

# Define metrics for alerting
PAYMENT_FAILURES = Counter(...)
PAYMENT_DURATION = Summary(...)
PAYMENT_AMOUNT = Summary(...)
PAYMENT_PROCESSING = Gauge(...)

def process_payment(payment_data):
    ...
```

**Also suggest alert rule configuration (Prometheus):**

```yaml
groups:
- name: payment_service_alerts
  rules:
  - alert: PaymentFailureRateHigh
    expr: ...
  - alert: PaymentProcessingTime
    expr: ...
  - alert: StuckPaymentProcessing
    expr: ...
```

---

### Example: Incident Response Runbook

```markdown
## Incident Classification
## Initial Response Steps
## Diagnostic Steps
## Resolution Steps
## Communication Templates
## Post-Resolution Actions
```

---

### Example: Post-Mortem Template

```markdown
## Incident Summary
## Timeline
## Root Cause Analysis
## Action Items
## Lessons Learned
## Appendix
```

---

### Example: SLO Implementation

```python
# FastAPI or similar app middleware for metrics
@app.middleware("http")
async def monitor_requests(request, call_next):
    ...
```

**SLO Definition File:**

```yaml
version: 1
service: payment-api
slos:
  - name: availability
    ...
  - name: latency
    ...
```

---

## Adaptations and Context-Awareness

Cursor will adjust operations and incident management recommendations based on:

- **Project Scale**
	-- Simpler approaches for small projects
	-- More comprehensive procedures for enterprise applications
	-- Appropriate tooling suggestions based on team size

- **Application Criticality**
	-- More stringent monitoring for business-critical functions
	-- Appropriate alerting thresholds based on service importance
	-- SLO recommendations aligned with business impact

- **Technology Stack**
	-- Framework-specific monitoring approaches
	-- Appropriate logging implementation for the language
	-- Matched alerting tools to existing infrastructure

- **Operational Maturity**
	-- Gradual sophistication of recommendations based on current practices
	-- Building on existing monitoring before suggesting advanced techniques
	-- Appropriate complexity level for documentation and runbooks
- **Deployment Frequency**
	-- Incident management approaches suited to release cadence
	-- Change management suggestions appropriate to deployment patterns
	-- Monitoring strategies aligned with update frequency

