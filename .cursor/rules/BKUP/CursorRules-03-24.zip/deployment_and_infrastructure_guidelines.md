# Cursor Deployment & Infrastructure Guidelines

These guidelines instruct Cursor on how to assist with deployment, infrastructure, and operational aspects of software development. They define how Cursor should analyze, suggest improvements, and generate configurations for deployment pipelines and infrastructure, ensuring recommendations are precise, actionable, and tailored to the project's context.

---

## 1. Deployment Strategy Assistance

### Pipeline Detection & Recommendations
- Identify existing CI/CD configurations (e.g., GitHub Actions, Jenkins, GitLab CI).
- Suggest specific improvements to build, test, and deployment workflows:
  - Add parallel testing to reduce CI build times.
  - Cache dependencies (e.g., `npm ci` with caching in GitHub Actions) to speed up builds.
- Flag missing steps in deployment pipelines (e.g., security scanning, test coverage).
- Generate configuration templates for missing pipeline components.

### Containerization Support
- Detect containerization needs based on project structure.
- Suggest Dockerfile optimizations with examples:
  - Use multi-stage builds to reduce image size.
  - Minimize layers by combining `RUN` commands.
- Generate efficient Dockerfiles with appropriate base images and multi-stage builds.
- Provide docker-compose configurations for local development environments.

### Deployment Procedure Assistance
- Recommend clear procedures for code promotion between environments:
  - Use Git tags for versioning releases.
  - Automate promotion with scripts for staging-to-production workflows.
- Suggest environment-specific configuration management approaches.
- Identify hardcoded environment values and suggest externalization.
- Generate deployment documentation templates.

---

## 2. Rollback Mechanism Support

### Rollback Strategy Suggestions
- Suggest appropriate rollback strategies with examples:
  - Use blue/green deployments for web applications to enable quick rollbacks.
  - Implement database transaction rollbacks or versioned schema migrations for data changes.
- Generate rollback scripts or commands for different deployment scenarios.
- Flag deployments lacking clear rollback mechanisms.
- Recommend database migration rollback procedures.

### Deployment Safety Enhancements
- Suggest feature flag implementations for risky changes using tools like LaunchDarkly or Unleash.
- Recommend canary deployment approaches for critical updates.
- Identify potential points of failure in deployment processes.
- Suggest blue/green deployment configurations when appropriate.

### Testing Rollback Procedures
- Recommend automated testing of rollback procedures.
- Suggest verification steps post-rollback.
- Flag untested rollback mechanisms.
- Generate test scripts for validating rollback processes.

---

## 3. Monitoring Implementation

### Monitoring Configuration Assistance
- Identify appropriate monitoring tools based on the project’s technology stack.
- Generate monitoring configuration files (e.g., Prometheus, Datadog).
- Suggest health check endpoints for services.
- Recommend application-specific metrics to track.

### Alert Configuration
- Suggest precise alert thresholds for key service metrics:
  - Alert when 5xx errors exceed 1% of total requests.
  - Set CPU usage alerts at 80% for 5 minutes.
- Generate alerting rules for critical conditions.
- Recommend appropriate alert routing and escalation.
- Flag missing alerts for critical functionality.

### Dashboard Creation
- Generate dashboard configurations for visualization tools.
- Suggest key metrics to display on operational dashboards:
  - Track response times, error rates, and throughput for APIs.
  - Monitor database connections and query performance for data-heavy apps.
- Recommend visualization approaches for different metric types.
- Provide templates for status pages and user-facing monitoring.

---

## 4. Logging Enhancement

### Logging Implementation
- Identify inconsistent logging patterns.
- Suggest structured logging implementations.
- Generate log configuration for centralized solutions (e.g., ELK stack).
- Recommend standardized log levels and their appropriate usage.

### Log Content Optimization
- Flag sensitive data in log messages and suggest data masking or redaction.
- Recommend including contextual information in logs (e.g., user IDs, timestamps).
- Suggest correlation IDs for request tracing.
- Identify insufficient error logging.

### Log Management
- Suggest log rotation and retention policies:
  - Retain logs for 30 days with daily rotation.
  - Archive logs older than 7 days to cold storage.
- Recommend archival strategies for historical logs.
- Generate log aggregation configurations.
- Suggest log analysis approaches for identifying patterns.

---

## 5. Performance Metrics & Optimization

### Performance Monitoring & Analysis
- Suggest critical performance indicators for different service types.
- Generate monitoring configurations for performance metrics.
- Recommend baseline thresholds for performance alerts.
- Identify missing performance measurements.

### Performance Optimization
- Flag potential performance bottlenecks in code.
- Recommend tools and techniques:
  - Use profiling tools (e.g., `cProfile` for Python) to identify slow functions.
  - Apply static analysis to detect inefficient loops or queries.
- Suggest caching strategies where appropriate.
- Recommend database query optimizations.
- Identify resource-intensive operations that could be optimized.

### Scaling Guidance
- Suggest auto-scaling configurations with specific triggers:
  - Scale up when CPU usage exceeds 70% for 5 minutes.
  - Scale down when traffic drops below a defined threshold.
- Recommend horizontal vs. vertical scaling approaches.
- Generate infrastructure-as-code for scalable architectures.
- Identify components that may become scaling bottlenecks.

---

## 6. Infrastructure-as-Code Support

### IaC Implementation
- Provide Terraform, CloudFormation, or other IaC templates.
- Suggest best practices:
  - Version control IaC templates in a separate repository.
  - Use modules for reusable infrastructure components.
- Generate modular, reusable infrastructure components.
- Flag hardcoded values in infrastructure definitions.

### Security Best Practices
- Identify insecure infrastructure configurations with examples:
  - Flag open security groups (e.g., `0.0.0.0/0` on port 22).
  - Recommend least-privilege IAM roles for services.
- Suggest security group and network access limitations.
- Recommend encryption for data at rest and in transit.
- Flag excessive permissions in service roles.

### Environment Consistency
- Suggest approaches for maintaining parity between environments.
- Identify environment-specific configurations that should be parameterized.
- Generate environment configuration files with appropriate defaults.
- Recommend strategies for environment secret management.

---

## 7. Disaster Recovery Planning

### DR Strategy
- Suggest backup strategies for different data types.
- Generate backup configuration scripts.
- Recommend backup frequency and retention policies.
- Flag critical data without backup procedures.
- Conduct regular DR drills to test recovery procedures.
- Set up automated failover for critical services.

### Recovery Procedure Assistance
- Generate disaster recovery runbooks.
- Suggest recovery time objective (RTO) targets.
- Recommend recovery testing procedures.
- Identify single points of failure in architecture.

### Resilience Enhancement
- Suggest multi-region deployment configurations.
- Recommend redundancy for critical components.
- Generate chaos engineering test scenarios.
- Flag availability concerns in architecture.

---

## Implementation Examples

### Example: Dockerfile Optimization
```dockerfile
# Original Dockerfile
FROM ubuntu:latest
RUN apt-get update
RUN apt-get install -y python3 python3-pip
COPY . /app
WORKDIR /app
RUN pip3 install -r requirements.txt
CMD ["python3", "app.py"]

Optimized Version:
dockerfile

# Optimized Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Copy and install dependencies first (better layer caching)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Run as non-root user for security
RUN useradd -m appuser
USER appuser

# Health check for container orchestration
HEALTHCHECK --interval=30s --timeout=3s \
  CMD curl -f http://localhost:8000/health || exit 1

CMD ["python", "app.py"]

Example: CI/CD Pipeline Enhancement
yaml

# Original workflow
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build
        run: docker build -t myapp .
      - name: Deploy
        run: ./deploy.sh

Enhanced Version:
yaml

# Enhanced workflow with testing, security scanning, and rollback
name: Build, Test, and Deploy

on:
  push:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Run tests
        run: pytest
      - name: Check test coverage
        run: pytest --cov=app --cov-fail-under=80

  security-scan:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run dependency security scan
        uses: snyk/actions/python@master
      - name: Run code security scan
        uses: github/codeql-action/analyze@v1

  deploy:
    needs: [test, security-scan]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Build
        run: docker build -t myapp:${{ github.sha }} .
      - name: Tag stable
        run: docker tag myapp:${{ github.sha }} myapp:stable
      - name: Deploy
        run: ./deploy.sh
      - name: Verify deployment
        run: ./verify_deployment.sh
      - name: Rollback on failure
        if: failure()
        run: ./rollback.sh

Example: Logging Configuration
python

# Original code with inconsistent logging
import logging

def process_payment(payment_data):
    print(f"Processing payment for {payment_data['amount']}")
    try:
        result = payment_service.charge(payment_data)
        logging.info("Payment processed")
        return result
    except Exception as e:
        print(f"Error in payment: {str(e)}")
        return None

Enhanced Version:
python

# Standardized structured logging
import logging
import json

logger = logging.getLogger(__name__)

def process_payment(payment_data, request_id=None):
    logger.info("Processing payment", extra={
        "request_id": request_id,
        "amount": payment_data["amount"],
        "currency": payment_data["currency"],
        "payment_method": payment_data["method"]
    })
    try:
        result = payment_service.charge(payment_data)
        logger.info("Payment processed successfully", extra={
            "request_id": request_id,
            "transaction_id": result["transaction_id"],
            "status": result["status"]
        })
        return result
    except Exception as e:
        logger.error("Payment processing failed", extra={
            "request_id": request_id,
            "error": str(e),
            "payment_method": payment_data["method"]
        })
        return None

Example: Monitoring Configuration
python

# Prometheus monitoring configuration for a Flask application
from prometheus_client import Counter, Histogram
from prometheus_flask_exporter import PrometheusMetrics

metrics = PrometheusMetrics(app)

REQUEST_COUNT = Counter(
    'request_count', 'App Request Count',
    ['app_name', 'method', 'endpoint', 'http_status']
)
REQUEST_LATENCY = Histogram(
    'request_latency_seconds', 'Request latency',
    ['app_name', 'endpoint']
)

@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    REQUEST_COUNT.labels(
        'my_app', 
        request.method, 
        request.path, 
        response.status_code
    ).inc()
    request_latency = time.time() - request.start_time
    REQUEST_LATENCY.labels('my_app', request.path).observe(request_latency)
    return response

@app.route('/health')
@metrics.do_not_track()
def health():
    return {"status": "healthy"}

Adaptations and Context-Awareness
Cursor will adjust deployment and infrastructure recommendations based on:
Project Scale:
Simpler configurations for small projects (e.g., lightweight monitoring tools like Grafana Cloud).

More comprehensive setups for enterprise applications (e.g., robust solutions like Datadog or New Relic).

Technology Stack:
Framework-specific deployment strategies (e.g., serverless for AWS Lambda functions).

Language-appropriate monitoring and logging approaches (e.g., structured logging for Python with logging module).

Observed Infrastructure:
Adaptation to detected cloud providers or hosting environments (e.g., AWS, GCP, on-prem).

Respect for existing architectural decisions (e.g., microservices vs. monolith).

Deployment Frequency:
Optimize for observed deployment patterns (e.g., frequent releases may benefit from canary deployments).

Suggest appropriate automation based on release cadence (e.g., automated testing for daily deploys).

Application Type:
Different approaches for APIs, web applications, data processing services (e.g., batch jobs vs. real-time services).

Specialized monitoring for different service types (e.g., database metrics for data-heavy apps).

Final Notes
This updated "Cursor Deployment & Infrastructure Guidelines" provides precise, actionable, and context-aware recommendations. With specific examples, tools, and best practices, it ensures effective assistance with deployment, infrastructure, and operational tasks across various software development scenarios.


