# Comprehensive Development Guidelines

This file serves as the main entry point for all development guidelines for our projects. It includes references to specialized guideline documents that cover various aspects of our development process.

## Table of Contents

- [Coding Patterns](#coding-patterns)
- [Testing Framework](#testing-framework)
- [Workflow Guidelines](#workflow-guidelines)
- [Deployment & Infrastructure](#deployment-and-infrastructure)
- [Integration & Third-Party Dependencies](#integration-and-third-party-dependencies)
- [Operations & Incident Management](#operations-and-incident-management)
- [Security & Compliance](#security-and-compliance)
- [Technical Stack](#technical-stack)

## Included Guidelines

@include(./coding_pattern_guideline.md)
@include(./coding_test_harness.md)
@include(./coding_workflow_guidelines.md)
@include(./deployment_and_infrastructure_guidelines.md)
@include(./integration_and_third_party_dependencies_guidelines.md)
@include(./operations_and_incident_guidelines.md)
@include(./security_and_compliance_guidelines.md)
@include(./technical_stack_guidelines.md)

## Usage

These guidelines apply to all projects and should be followed by all team members. Use these guidelines as a reference when:

1. Developing new features
2. Fixing bugs
3. Creating tests
4. Reviewing code
5. Setting up infrastructure
6. Handling incidents
7. Selecting technologies

The AI assistant has been trained to understand and follow these guidelines when providing assistance.
