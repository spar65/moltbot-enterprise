Cursor Integration & Third-Party Dependencies Guidelines
These guidelines outline how Cursor should operate as an automated tool to enhance integration patterns and manage third-party dependencies in codebases. The focus is on specific, actionable steps Cursor must take to analyze, suggest, and implement improvements without human intervention.
1. Integration Pattern Assistance
Detect and Document Integrations:
Cursor should scan the codebase for external service integrations (e.g., API clients) and automatically insert documentation. This includes:  
Adding code comments above detected API calls with details like endpoints and authentication methods (e.g., OAuth, API keys).  

Generating a docs/integrations.md file summarizing all integrations.

Generate and Insert Test Snippets:
Cursor should create and add test cases for integrations directly into the project’s test suite, using tools like:  
unittest.mock for Python projects.  

sinon for JavaScript projects.
These tests should mock external APIs to ensure reliability.

2. Integration Standardization
Generate and Apply Adapter Code:
Cursor should identify inconsistent integration patterns and:  
Generate a standardized adapter (e.g., an ApiClient class or module).  

Refactor existing code to use this adapter for all similar services.

Automate Migration with Scripts:
Cursor should produce and run scripts to transition the codebase to standardized patterns incrementally, including:  
A script file (e.g., migrate_api_calls.py or migrate-api-calls.js).  

Step-by-step commits to apply changes safely.

3. Secret Management
Refactor to Environment Variables:
Cursor should detect hardcoded credentials and refactor them to use:  
Environment variables via os.getenv() in Python or process.env in JavaScript.  

A .env.example file with placeholder values for setup guidance.

Generate Rotation Scripts:
Cursor should create executable scripts to rotate secrets, such as:  
A script to regenerate and update API keys (e.g., rotate_secrets.py or rotate-secrets.js).  

Instructions in the script comments for manual verification if needed.

4. Dependency Reliability
Insert Monitoring Code:
Cursor should add monitoring instrumentation to dependency calls, including:  
Metrics like latency and errors using Prometheus (e.g., EXTERNAL_REQUEST_DURATION and EXTERNAL_REQUEST_FAILURES).  

Logging for failures with appropriate libraries (e.g., logging in Python, console in JavaScript).

Generate and Apply Fallback Logic:
Cursor should insert fallback mechanisms into dependency calls, such as:  
Cached responses stored in memory or a file.  

Default values returned on failure (e.g., a placeholder object).

5. Dependency Version Management
Automate Version Pinning:
Cursor should update dependency configuration files to pin versions, such as:  
package.json in Node.js projects (e.g., "express": "4.17.1" instead of "^4.17.1").  

requirements.txt in Python projects (e.g., requests==2.28.1).

Generate Update Scripts:
Cursor should create scripts for safe dependency updates, including:  
A script file (e.g., update_deps.sh or update-deps.js).  

Steps to test updates locally before committing.

6. Adaptations and Context-Awareness
Dynamically Tailor Actions:
Cursor should adjust its actions based on project context, such as:  
Using simpler patterns (e.g., basic retries) for small projects.  

Implementing robust solutions (e.g., circuit breakers) for critical systems.

Automate Context Detection:
Cursor should infer project details from the codebase and adapt accordingly, including:  
Language detection (e.g., Python, JavaScript).  

Framework detection (e.g., Django, Express) to apply relevant patterns.

This document defines what Cursor should include in its automation—code generation, refactoring, documentation, and scripts—and how it should use these tools to enhance integration and dependency management. It ensures Cursor acts proactively, precisely, and context-aware, directly improving codebases without requiring human oversight.


